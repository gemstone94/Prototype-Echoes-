const PALETTES = Object.freeze({
  Fire: {sky:0x070b1c, nebula:0x3a123b, aura:0xff6f4e, emissive:0xffb06a},
  Earth: {sky:0x06101a, nebula:0x153d42, aura:0x8ce3a7, emissive:0x9fffc7},
  Air: {sky:0x071322, nebula:0x263f69, aura:0x8ad9ff, emissive:0xc4f1ff},
  Water: {sky:0x04101b, nebula:0x123d55, aura:0x5ed8ff, emissive:0x8df5ff}
});
export function visualProfileFromPhenotype(p={}){return{
 bodyScale:{x:.78+(p.mass??1)*.62,y:.62+(p.armor??.5)*.3,z:.95+(p.mass??1)*.82},
 glowIntensity:1.2+(p.luminescence??.5)*2.4,
 rimIntensity:.45+(p.senses??.5)*.9,
 armorDensity:.25+(p.armor??.5)*.75,
 limbCount:p.limbCount??4,
 eyeScale:.8+(p.senses??.5)*.5
};}
export function celestialPalette(c={}){return PALETTES[c.element]||PALETTES.Air;}

const STATE_PULSE = Object.freeze({
  idle: 1,
  foraging: 1.08,
  alert: 1.2,
  fleeing: 1.35,
  stalking: 1.3,
  hunting: 1.55,
  'pack-hunting': 1.72,
  feeding: 1.15,
  resting: 0.78,
  territorial: 1.42,
  migrating: 1.18,
  bonded: 1.28
});

export function bioluminescenceProfile(entity={}, weather={}) {
  const phenotype = entity.phenotype || {};
  const statePulse = STATE_PULSE[entity.state] || 1;
  const environmental = 1 + (weather.bloomIntensity ?? 0) * 0.45 + (weather.astralPressure ?? 0) * 0.35 + (weather.stormIntensity ?? 0) * 0.25;
  return {
    intensity: (0.8 + (phenotype.luminescence ?? 0.5) * 1.8) * statePulse * environmental,
    pulseSpeed: 0.7 + statePulse * 0.65 + (weather.stormIntensity ?? 0) * 0.8,
    bloom: 0.12 + (phenotype.luminescence ?? 0.5) * 0.16 + (weather.bloomIntensity ?? 0) * 0.2
  };
}

export function environmentalVisualProfile(weather={}) {
  const storm = weather.stormIntensity ?? 0;
  const voidIntensity = weather.voidIntensity ?? 0;
  const pressure = weather.astralPressure ?? 0;
  return {
    fogDensity: 0.012 + storm * 0.018 + voidIntensity * 0.009,
    particleEnergy: 0.25 + storm * 0.7 + pressure * 0.9 + (weather.bloomIntensity ?? 0) * 0.45,
    lightShafts: 0.15 + (weather.luminosity ?? 0.5) * 0.35 + pressure * 0.3,
    stormCharge: storm * 1.4 + pressure * 0.5
  };
}

export function tierVisualProfile(tier='creature') {
  if (tier === 'Astral Titan') return { scale: 5.8, aura: 2.4, atmospheric: 1.9, particleRadius: 14 };
  if (tier === 'Apex Beast') return { scale: 2.7, aura: 1.35, atmospheric: 0.9, particleRadius: 6 };
  return { scale: 1, aura: 0.65, atmospheric: 0.35, particleRadius: 2 };
}

const MOTION_PULSE = Object.freeze({
  idle: 0.35, foraging: 0.55, alert: 0.9, fleeing: 1.45, stalking: 1.05,
  hunting: 1.25, 'pack-hunting': 1.5, feeding: 0.7, resting: 0.18,
  territorial: 1.0, migrating: 0.85, bonded: 0.5
});

export function creatureMotionProfile(entity={}, timeScale=1) {
  const phenotype=entity.phenotype||{};
  const pulse=MOTION_PULSE[entity.state]??0.5;
  const mass=phenotype.mass??1;
  const senses=phenotype.senses??0.5;
  return {
    stride:(0.18+pulse*.42+senses*.08)*timeScale,
    breathing:(0.25+pulse*.3+mass*.035)*timeScale,
    tension:Math.min(1.8,0.18+pulse*.5+senses*.22),
    bob:(0.015+pulse*.025)*timeScale,
    sway:(0.02+pulse*.04)*timeScale
  };
}

export function encounterCameraProfile(entity={}) {
  if(entity.tier==='Astral Titan') return {distance:1.7, shake:'heavy', lookOffset:7, cinematic:1};
  if(entity.tier==='Apex Beast') return {distance:2.4, shake:'medium', lookOffset:2.6, cinematic:.8};
  if(entity.state==='fleeing'||entity.state==='pack-hunting'||entity.state==='hunting') return {distance:3.1, shake:'light', lookOffset:1.3, cinematic:.5};
  return {distance:4.2, shake:'none', lookOffset:.9, cinematic:.2};
}

export function vegetationReactionProfile(entity={}, weather={}) {
  const motion=creatureMotionProfile(entity);
  const storm=weather.stormIntensity??0;
  return {sway:motion.sway+storm*.12, pulse:0.5+motion.tension*.45+(weather.bloomIntensity??0)*.25, recoil:Math.min(1,motion.tension*.7)};
}

export function cinematicEnvironmentProfile(weather={}) {
  const storm=weather.stormIntensity??0;
  const pressure=weather.astralPressure??0;
  const voidIntensity=weather.voidIntensity??0;
  return {
    wind:0.12+storm*.9+pressure*.18,
    lightning:storm*.95+pressure*.55,
    contrast:.55+storm*.35+pressure*.28+voidIntensity*.2,
    fog:.012+storm*.022+voidIntensity*.014,
    exposure:.98+(weather.luminosity??.5)*.16-pressure*.08
  };
}

const ANIMATION_STATE = Object.freeze({
  idle:{gait:.2,attack:0,breath:.35,foot:.08},
  foraging:{gait:.38,attack:.08,breath:.42,foot:.14},
  alert:{gait:.3,attack:.2,breath:.62,foot:.12},
  fleeing:{gait:1.25,attack:.05,breath:.85,foot:.42},
  stalking:{gait:.62,attack:.48,breath:.58,foot:.2},
  hunting:{gait:1.05,attack:.82,breath:.8,foot:.36},
  'pack-hunting':{gait:1.28,attack:1,breath:.92,foot:.48},
  feeding:{gait:.3,attack:.02,breath:.52,foot:.08},
  resting:{gait:.08,attack:0,breath:.18,foot:.02},
  territorial:{gait:.48,attack:.7,breath:.76,foot:.15},
  migrating:{gait:.72,attack:.1,breath:.6,foot:.24},
  bonded:{gait:.22,attack:.04,breath:.46,foot:.06}
});

export function creatureAnimationProfile(entity={}) {
  const state=ANIMATION_STATE[entity.state]||ANIMATION_STATE.idle;
  const p=entity.phenotype||{};
  const mass=p.mass??1;
  const senses=p.senses??.5;
  const tier=entity.tier;
  const weight=tier==='Astral Titan'?1.65:tier==='Apex Beast'?1.3:1;
  return {
    gait:state.gait*(.9+senses*.12)*weight,
    attackReadiness:Math.min(1.5,state.attack*(1+senses*.12)),
    breathAmplitude:(state.breath*(.7+mass*.08))/Math.max(1,weight*.72),
    breathSpeed:(.55+state.breath*.5)/Math.max(1,weight*.82),
    footLift:state.foot*(.9+senses*.08),
    recoil:state.attack*(.16+mass*.035),
    headTracking:.18+senses*.22+state.attack*.12
  };
}

export function encounterSequenceProfile(phase='discovery') {
  const profiles={
    discovery:{phase:'discovery',cameraImpulse:.05,atmosphericFade:.18,focus:1},
    pursuit:{phase:'pursuit',cameraImpulse:.22,atmosphericFade:.42,focus:1.18},
    impact:{phase:'impact',cameraImpulse:1,atmosphericFade:1,focus:1.5},
    release:{phase:'release',cameraImpulse:.16,atmosphericFade:.22,focus:.92}
  };
  return profiles[phase]||profiles.discovery;
}

export function titanImpactProfile(intensity=0) {
  const i=Math.max(0,Math.min(1,intensity));
  return {
    shadowRadius:10+i*42,
    particleBurst:80+i*520,
    cameraImpulse:.08+i*1.35,
    terrainPulse:.04+i*.65,
    atmosphereDistortion:.1+i*.9,
    lightDrop:i*.32
  };
}
