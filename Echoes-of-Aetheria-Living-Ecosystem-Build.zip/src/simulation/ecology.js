export const ECO_STATE = Object.freeze({
  IDLE: 'idle', FORAGING: 'foraging', ALERT: 'alert', FLEEING: 'fleeing', STALKING: 'stalking',
  HUNTING: 'hunting', FEEDING: 'feeding', RESTING: 'resting', TERRITORIAL: 'territorial', MIGRATING: 'migrating', BONDED: 'bonded'
});

const SPECIES = Object.freeze({
  Mossback: { kind: 'prey', diet: ['Lumenfern'], senses: ['sight', 'scent', 'resonance'], speed: 2.2, fear: 0.75, recovery: 0.006 },
  EmberStalker: { kind: 'predator', diet: ['Mossback'], senses: ['sight', 'scent', 'resonance'], speed: 4.3, fear: 0.15, recovery: 0.001 },
  Lumenfern: { kind: 'flora', diet: [], senses: ['resonance'], speed: 0, fear: 0, recovery: 0.012 },
  Moonspore: { kind: 'flora', diet: [], senses: ['resonance'], speed: 0, fear: 0, recovery: 0.009 },
  Aetherwing: { kind: 'prey', diet: ['Moonspore'], senses: ['sight', 'resonance'], speed: 5.5, fear: 0.9, recovery: 0.004 }
});

function hashSeed(seed) {
  let h = seed >>> 0;
  return () => { h = Math.imul(1664525, h) + 1013904223 | 0; return (h >>> 0) / 4294967296; };
}
function distance(a,b){return Math.hypot(a.x-b.x,a.z-b.z)}
function clamp(v,min=0,max=1){return Math.max(min,Math.min(max,v))}
function cloneEntity(e){return {...e,position:{...e.position},home:{...e.home},territory:{...e.territory},senses:{...e.senses},memory:{...e.memory}}}

export function createEcosystem({seed=1, biome='Glowfen'}={}) {
  const random=hashSeed(seed), entities=[];
  const add=(species,index,kind=SPECIES[species].kind)=>{
    const angle=random()*Math.PI*2, radius=4+random()*28;
    const x=Math.cos(angle)*radius,z=Math.sin(angle)*radius;
    entities.push({id:`${species.toLowerCase()}-${index}`,species,kind,population:kind==='flora'?.65+random()*.3:.82+random()*.18,
      position:{x,z},home:{x,z},state:ECO_STATE.IDLE,energy:.55+random()*.4,health:1,
      senses:{sight:0,scent:0,resonance:.2+random()*.3},territory:{radius:kind==='predator'?16:7,alertness:0},memory:{disturbances:0,playerEncounters:0,lastEvent:null},phase:random()*Math.PI*2});
  };
  for(let i=0;i<7;i++) add('Lumenfern',i);
  for(let i=0;i<5;i++) add('Moonspore',i);
  for(let i=0;i<5;i++) add('Mossback',i);
  for(let i=0;i<3;i++) add('Aetherwing',i);
  for(let i=0;i<2;i++) add('EmberStalker',i);
  return {seed,biome,time:0,entities,events:[],weather:{luminosity:.72,astralPressure:.18}};
}

export function findEntity(ecosystem,id){return ecosystem.entities.find(e=>e.id===id)}

export function recordPlayerDisturbance(ecosystem,{x,z,type='presence'}={}){
  const entities=ecosystem.entities.map(e=>{
    if(e.kind!=='predator'||distance(e.position,{x,z})>e.territory.radius*1.8)return e;
    const next=cloneEntity(e);next.memory.disturbances++;next.memory.playerEncounters++;next.memory.lastEvent=type;next.territory.alertness=clamp(next.territory.alertness+.2);return next;
  });
  return {...ecosystem,entities,events:[...ecosystem.events,{time:ecosystem.time,type:'player-disturbance',x,z,event:type}]};
}

export function harvestFlora(ecosystem,id,amount=.1){
  const entities=ecosystem.entities.map(e=>e.id===id&&e.kind==='flora'?{...e,population:clamp(e.population-amount)}:e);
  return {...ecosystem,entities,events:[...ecosystem.events,{time:ecosystem.time,type:'harvest',target:id,amount}]};
}

function nearest(entities,source,predicate){let best=null,bestD=Infinity;for(const e of entities){if(e===source||!predicate(e))continue;const d=distance(source.position,e.position);if(d<bestD){best=e;bestD=d}}return [best,bestD]}
function moveToward(entity,target,amount){if(!target)return;const dx=target.x-entity.position.x,dz=target.z-entity.position.z,len=Math.hypot(dx,dz)||1;entity.position.x+=dx/len*amount;entity.position.z+=dz/len*amount}
function moveAway(entity,target,amount){if(!target)return;const dx=entity.position.x-target.x,dz=entity.position.z-target.z,len=Math.hypot(dx,dz)||1;entity.position.x+=dx/len*amount;entity.position.z+=dz/len*amount}

export function tickEcosystem(ecosystem,{player={x:0,z:0},dt=.016}={}){
  const entities=ecosystem.entities.map(cloneEntity), events=[];
  const playerPresence={...player};
  for(const e of entities){
    const def=SPECIES[e.species];
    if(e.kind==='flora'){
      e.population=clamp(e.population+def.recovery*dt*(1-e.population*.45));
      e.senses.resonance=clamp(e.senses.resonance+.01*dt);
      continue;
    }
    const pd=distance(e.position,playerPresence);
    e.senses.sight=clamp(1-pd/24);
    e.senses.scent=clamp(1-pd/32)*(.65+e.memory.disturbances*.04);
    e.senses.resonance=clamp(.2+ecosystem.weather.astralPressure*.5+Math.sin(ecosystem.time*.001+e.phase)*.08);
    e.energy=clamp(e.energy+(.05*dt)-(e.state===ECO_STATE.HUNTING?.035*dt:.008*dt),0,1);
    const [prey,preyD]=nearest(entities,e,x=>def.diet.includes(x.species)&&x.population>.12);
    if(e.kind==='predator'){
      const threat=clamp((24-pd)/24);
      if(pd<7){e.state=ECO_STATE.TERRITORIAL;e.territory.alertness=clamp(e.territory.alertness+.025*dt)}
      else if(prey&&preyD<20){e.state=preyD<7?ECO_STATE.HUNTING:ECO_STATE.STALKING;moveToward(e,prey.position,def.speed*dt*(preyD<7?1:.35))}
      else if(e.territory.alertness>.12){e.state=ECO_STATE.TERRITORIAL;moveToward(e,e.home,def.speed*dt*.22);e.territory.alertness=clamp(e.territory.alertness-.01*dt)}
      else {e.state=ECO_STATE.FORAGING;moveToward(e,e.home,def.speed*dt*.08)}
      if(prey&&preyD<2.1&&prey.population>.05){prey.population=clamp(prey.population-.035*dt);e.energy=clamp(e.energy+.05*dt);e.state=ECO_STATE.FEEDING;events.push({time:ecosystem.time,type:'predation',predator:e.id,prey:prey.id})}
      if(threat>.7&&e.memory.disturbances>0)e.state=ECO_STATE.TERRITORIAL;
    } else {
      if(pd<10*def.fear)e.state=ECO_STATE.FLEEING;
      else if(prey&&preyD<6)e.state=ECO_STATE.FORAGING;
      else if(distance(e.position,e.home)>12)e.state=ECO_STATE.MIGRATING;
      else e.state=e.energy<.25?ECO_STATE.RESTING:ECO_STATE.FORAGING;
      if(e.state===ECO_STATE.FLEEING)moveAway(e,playerPresence,def.speed*dt);
      else if(e.state===ECO_STATE.MIGRATING)moveToward(e,e.home,def.speed*dt*.3);
      else if(prey)e.state=ECO_STATE.FORAGING;
      if(e.energy<.9)e.energy=clamp(e.energy+.02*dt);
    }
    e.position.x=clamp(e.position.x,-80,80);e.position.z=clamp(e.position.z,-80,80);
  }
  return {...ecosystem,time:ecosystem.time+dt,entities,events:[...ecosystem.events,...events].slice(-80),weather:{...ecosystem.weather,astralPressure:clamp(.18+Math.sin((ecosystem.time+dt)*.00017)*.12)}};
}

export function ecosystemSnapshot(ecosystem){
  const populations={};for(const e of ecosystem.entities)populations[e.species]=(populations[e.species]||0)+e.population;
  return {time:ecosystem.time,biome:ecosystem.biome,populations,activePredators:ecosystem.entities.filter(e=>e.kind==='predator'&&e.state!=='idle').length,events:ecosystem.events.length};
}
