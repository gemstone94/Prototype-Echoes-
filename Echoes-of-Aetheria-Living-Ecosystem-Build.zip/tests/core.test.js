import test from 'node:test';
import assert from 'node:assert/strict';
import { zodiacFromBirth, createPlayer, recordMemory, unlockGlyph, meditate, buildConstellation, legendaryAscend, predatorProfile, combineRunes, RUNE, STAGE, deriveMutation, ecologicalResonance } from '../src/simulation/core.js';
import { createEcosystem, tickEcosystem, ecosystemSnapshot, findEntity, harvestFlora, recordPlayerDisturbance } from '../src/simulation/ecology.js';

test('birth date chooses the correct Martian lineage',()=>{assert.equal(zodiacFromBirth(3,21),'Aries');assert.equal(createPlayer(3,21).species,'Emberhorn');assert.equal(createPlayer(12,25).species,'Cragwalker')});
test('memory and glyphs drive evolution',()=>{let p=createPlayer(3,21);p=recordMemory(p,{type:'hunt',target:'Mossback'});p=unlockGlyph(p,'predator',"Hunter's Pulse");p=meditate(p);assert.equal(p.stage,1);assert.equal(p.memories.length,1)});
test('rune combinations unlock higher mutations',()=>{assert.deepEqual(combineRunes(['predator','astral']),{name:'Astral Hunt',runes:['predator','astral'],rarity:'rare'})});
test('constellation then ascension',()=>{let p=createPlayer(3,21);p=unlockGlyph(p,'predator','Hunter');for(let i=0;i<5;i++)p=meditate(p);p=buildConstellation(p);assert.equal(p.constellation.length,7);p=legendaryAscend(p);assert.equal(p.stage,6)});
test('predator tiers escalate in scale and threat',()=>{assert.ok(predatorProfile('Astral Titan').massScale>predatorProfile('Apex Beast').massScale);assert.equal(predatorProfile('Astral Titan').danger,1);assert.equal(predatorProfile('Astral Titan').beauty,1)});

test('celestial signature is deterministic and astrological', () => {
  const p = createPlayer(3,21);
  assert.equal(p.sign, 'Aries');
  assert.equal(p.celestial.element, 'fire');
  assert.equal(p.celestial.modality, 'cardinal');
  assert.equal(p.celestial.lunarAffinity, 'full');
  assert.ok(p.celestial.birthStar);
});

test('adaptation profile derives a mutation from rune history and biome exposure', () => {
  let p = createPlayer(3,21);
  p = recordMemory(p,{type:'hunt',target:'Mossback',biome:'Glowfen'});
  p = unlockGlyph(p,RUNE.PREDATOR,"Hunter's Pulse");
  p = unlockGlyph(p,RUNE.STALKER,'Ashstep');
  const mutation = deriveMutation(p);
  assert.equal(mutation.name, 'Apex Pursuer');
  assert.ok(mutation.physical.includes('crystalline shoulder plates'));
  assert.equal(mutation.biomeAffinity, 'Glowfen');
});

test('void resonance carries a measurable ecological cost', () => {
  let p = createPlayer(3,21);
  p = unlockGlyph(p,RUNE.VOID,'Null Resonance');
  p = unlockGlyph(p,RUNE.SYMBIOSIS,'Pack Bond');
  const ecology = ecologicalResonance(p);
  assert.ok(ecology.voidInstability > 0);
  assert.ok(ecology.symbiosisPenalty > 0);
});

test('constellation completes before legendary ascension and records pathway', () => {
  let p = createPlayer(3,21);
  p = unlockGlyph(p,RUNE.PREDATOR,'Hunter');
  p = { ...p, stage: STAGE.CONSTELLATION };
  p = buildConstellation(p);
  p = legendaryAscend(p);
  assert.equal(p.stage, STAGE.ASCENSION);
  assert.equal(p.ascensionPathway, 'Apex Emberborn');
  assert.equal(p.constellation.length, 7);
});

test('all twelve lineages have a celestial ascension identity', () => {
  const dates=[[3,21],[4,21],[5,21],[6,21],[7,23],[8,23],[9,23],[10,23],[11,23],[12,22],[1,21],[2,20]];
  for(const [month,day] of dates){
    let p=createPlayer(month,day);
    assert.ok(p.celestial.birthStar);
    p={...p,stage:STAGE.CONSTELLATION,constellation:['a','b','c','d','e','f','g']};
    assert.ok(legendaryAscend(p).ascensionPathway);
  }
});


test('living ecosystem tracks populations, senses, and food pressure', () => {
  let eco = createEcosystem({ seed: 7, biome: 'Glowfen' });
  assert.equal(eco.biome, 'Glowfen');
  assert.ok(eco.entities.length >= 8);
  const before = ecosystemSnapshot(eco);
  eco = tickEcosystem(eco, { player: { x: 0, z: 0 }, dt: 1 });
  const after = ecosystemSnapshot(eco);
  assert.notEqual(after.time, before.time);
  assert.ok(after.populations.Mossback > 0);
  assert.ok(after.populations.Lumenfern > 0);
});

test('predators react to prey and player through ecological senses', async () => {
  let eco = createEcosystem({ seed: 11, biome: 'Glowfen' });
  const predator = findEntity(eco, 'emberstalker-0');
  const prey = findEntity(eco, 'mossback-0');
  assert.ok(predator && prey);
  predator.position = { x: 0, z: 0 };
  prey.position = { x: 3, z: 0 };
  eco = tickEcosystem(eco, { player: { x: 40, z: 40 }, dt: 0.25 });
  const updated = findEntity(eco, 'emberstalker-0');
  assert.ok(['stalking', 'alert', 'hunting', 'feeding', 'foraging'].includes(updated.state));
  assert.ok(updated.senses.scent >= 0);
});

test('ecosystem responds to over-harvesting and recovers naturally', async () => {
  let eco = createEcosystem({ seed: 4, biome: 'Glowfen' });
  const flora = findEntity(eco, 'lumenfern-0');
  assert.ok(flora);
  const original = flora.population;
  for (let i = 0; i < 4; i++) eco = harvestFlora(eco, flora.id, 0.2);
  assert.ok(findEntity(eco, flora.id).population < original);
  for (let i = 0; i < 40; i++) eco = tickEcosystem(eco, { player: { x: 100, z: 100 }, dt: 1 });
  assert.ok(findEntity(eco, flora.id).population > 0);
});

test('territorial predators remember player disturbance', async () => {
  let eco = createEcosystem({ seed: 21, biome: 'Glowfen' });
  eco = recordPlayerDisturbance(eco, { x: 0, z: 0, type: 'hunt' });
  eco = tickEcosystem(eco, { player: { x: 0, z: 0 }, dt: 1 });
  const predator = findEntity(eco, 'emberstalker-0');
  assert.ok(predator.memory.disturbances >= 1);
  assert.ok(predator.territory.alertness > 0);
});
