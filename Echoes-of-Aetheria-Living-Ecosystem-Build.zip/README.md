# Echoes of Aetheria

Astronomical Aetheria browser vertical slice and expandable game foundation.

## Locked systems
- Birth month/day → zodiac → Martian lineage
- 12 playable lineage data definitions
- Adaptive memories and glyphs
- Rune combinations
- Seven evolution stages through Legendary Ascension
- Astronomical, bioluminescent world rendering
- Mossback hunting loop
- Stalker / Apex Beast / Astral Titan predator hierarchy
- DOM HUD separated from Three.js render graph

## Run
This prototype uses browser ESM imports from Three.js CDN, so it can be served by a static HTTP server without a package install:

`python3 -m http.server 4173`

Then open `http://localhost:4173`.

## Tests
`node --test`

## Living Ecosystem layer
The current vertical slice now includes a deterministic ecological simulation in `src/simulation/ecology.js`. Glowfen populations include Mossbacks, Aetherwings, Lumenfern, Moonspore, and EmberStalkers. Entities maintain states, senses, energy, territory, memories, population pressure, and recovery. Predators stalk and feed on prey, prey flee from player pressure, flora recovers, and player disturbances raise territorial alertness. The renderer treats this simulation as authoritative and mirrors creature positions/state into Three.js.

Run tests with `node --test`. Run locally with `python3 -m http.server 4173` and open `http://localhost:4173`.
