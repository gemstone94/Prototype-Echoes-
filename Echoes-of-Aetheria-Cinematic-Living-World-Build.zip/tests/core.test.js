import test from 'node:test';
import assert from 'node:assert/strict';
import { zodiacFromBirth, createPlayer, recordMemory, unlockGlyph, meditate, buildConstellation, legendaryAscend, predatorProfile, combineRunes, RUNE, STAGE, deriveMutation, ecologicalResonance } from '../src/simulation/core.js';
import { createEcosystem, tickEcosystem, ecosystemSnapshot, findEntity, harvestFlora, recordPlayerDisturbance, reproduceCreature, bindSymbiosis, triggerEnvironmentalEvent, createApexBeast, createAstralTitan } from '../src/simulation/ecology.js';

test('birth date chooses the correct Martian lineage',()=>{assert.equal(zodiacFromBirth(3,21),'Aries');assert.equal(createPlayer(3,21).species,'Emberhorn');assert.equal(createPlayer(12,25).species,'Cragwalker')});
test('memory and glyphs drive evolution',()=>{let p=createPlayer(3,21);p=recordMemory(p,{type:'hunt',target:'Mossback'});p=unlockGlyph(p,'predator',"Hunter's Pulse");p=meditate(p);assert.equal(p.stage,1);assert.equal(p.memories.length,1)});
test('rune combinations unlock higher mutations',()=>{assert.deepEqual(combineRunes(['predator','astral']),{name:'Astral Hunt',runes:['predator','astral'],rarity:'rare'})});
test('constellation then ascension',()=>{let p=createPlayer(3,21);p=unlockGlyph(p,'predator','Hunter');for(let i=0;i<5;i++)p=meditate(p);p=buildConstellation(p);assert.equal(p.constellation.length,7);p=legendaryAscend(p);assert.equal(p.stage,6)});
test('predator tiers escalate in scale and threat',()=>{assert.ok(predatorProfile('Astral Titan').massScale>predatorProfile('Apex Beast').massScale);assert.equal(predatorProfile('Astral Titan').danger,1);assert.equal(predatorProfile('Astral Titan').beauty,1)});

test('celestial signature is deterministic and astrological', () => {
  const p = createPlayer(3,21);
  assert.equal(p.sign, 'Aries');
  assert.equal(p.celestial.element, 'fire');
  assert.equal(p.celestial.modality, 'cardinal');
  assert.equal(p.celestial.lunarAffinity, 'full');
  assert.ok(p.celestial.birthStar);
});

test('adaptation profile derives a mutation from rune history and biome exposure', () => {
  let p = createPlayer(3,21);
  p = recordMemory(p,{type:'hunt',target:'Mossback',biome:'Glowfen'});
  p = unlockGlyph(p,RUNE.PREDATOR,"Hunter's Pulse");
  p = unlockGlyph(p,RUNE.STALKER,'Ashstep');
  const mutation = deriveMutation(p);
  assert.equal(mutation.name, 'Apex Pursuer');
  assert.ok(mutation.physical.includes('crystalline shoulder plates'));
  assert.equal(mutation.biomeAffinity, 'Glowfen');
});

test('void resonance carries a measurable ecological cost', () => {
  let p = createPlayer(3,21);
  p = unlockGlyph(p,RUNE.VOID,'Null Resonance');
  p = unlockGlyph(p,RUNE.SYMBIOSIS,'Pack Bond');
  const ecology = ecologicalResonance(p);
  assert.ok(ecology.voidInstability > 0);
  assert.ok(ecology.symbiosisPenalty > 0);
});

test('constellation completes before legendary ascension and records pathway', () => {
  let p = createPlayer(3,21);
  p = unlockGlyph(p,RUNE.PREDATOR,'Hunter');
  p = { ...p, stage: STAGE.CONSTELLATION };
  p = buildConstellation(p);
  p = legendaryAscend(p);
  assert.equal(p.stage, STAGE.ASCENSION);
  assert.equal(p.ascensionPathway, 'Apex Emberborn');
  assert.equal(p.constellation.length, 7);
});

test('all twelve lineages have a celestial ascension identity', () => {
  const dates=[[3,21],[4,21],[5,21],[6,21],[7,23],[8,23],[9,23],[10,23],[11,23],[12,22],[1,21],[2,20]];
  for(const [month,day] of dates){
    let p=createPlayer(month,day);
    assert.ok(p.celestial.birthStar);
    p={...p,stage:STAGE.CONSTELLATION,constellation:['a','b','c','d','e','f','g']};
    assert.ok(legendaryAscend(p).ascensionPathway);
  }
});


test('living ecosystem tracks populations, senses, and food pressure', () => {
  let eco = createEcosystem({ seed: 7, biome: 'Glowfen' });
  assert.equal(eco.biome, 'Glowfen');
  assert.ok(eco.entities.length >= 8);
  const before = ecosystemSnapshot(eco);
  eco = tickEcosystem(eco, { player: { x: 0, z: 0 }, dt: 1 });
  const after = ecosystemSnapshot(eco);
  assert.notEqual(after.time, before.time);
  assert.ok(after.populations.Mossback > 0);
  assert.ok(after.populations.Lumenfern > 0);
});

test('predators react to prey and player through ecological senses', async () => {
  let eco = createEcosystem({ seed: 11, biome: 'Glowfen' });
  const predator = findEntity(eco, 'emberstalker-0');
  const prey = findEntity(eco, 'mossback-0');
  assert.ok(predator && prey);
  predator.position = { x: 0, z: 0 };
  prey.position = { x: 3, z: 0 };
  eco = tickEcosystem(eco, { player: { x: 40, z: 40 }, dt: 0.25 });
  const updated = findEntity(eco, 'emberstalker-0');
  assert.ok(['stalking', 'alert', 'hunting', 'feeding', 'foraging'].includes(updated.state));
  assert.ok(updated.senses.scent >= 0);
});

test('ecosystem responds to over-harvesting and recovers naturally', async () => {
  let eco = createEcosystem({ seed: 4, biome: 'Glowfen' });
  const flora = findEntity(eco, 'lumenfern-0');
  assert.ok(flora);
  const original = flora.population;
  for (let i = 0; i < 4; i++) eco = harvestFlora(eco, flora.id, 0.2);
  assert.ok(findEntity(eco, flora.id).population < original);
  for (let i = 0; i < 40; i++) eco = tickEcosystem(eco, { player: { x: 100, z: 100 }, dt: 1 });
  assert.ok(findEntity(eco, flora.id).population > 0);
});

test('territorial predators remember player disturbance', async () => {
  let eco = createEcosystem({ seed: 21, biome: 'Glowfen' });
  eco = recordPlayerDisturbance(eco, { x: 0, z: 0, type: 'hunt' });
  eco = tickEcosystem(eco, { player: { x: 0, z: 0 }, dt: 1 });
  const predator = findEntity(eco, 'emberstalker-0');
  assert.ok(predator.memory.disturbances >= 1);
  assert.ok(predator.territory.alertness > 0);
});

test('genomes inherit traits and express deterministic phenotypes', () => {
  const a = createEcosystem({seed: 2});
  const parentA = findEntity(a, 'mossback-0');
  const parentB = findEntity(a, 'mossback-1');
  assert.ok(parentA.genome && parentB.genome);
  const child = reproduceCreature(a, parentA.id, parentB.id, 77);
  assert.equal(child.species, 'Mossback');
  assert.ok(child.genome);
  assert.ok(child.phenotype.mass > 0);
  assert.deepEqual(child.phenotype, reproduceCreature(a, parentA.id, parentB.id, 77).phenotype);
});

test('predator intelligence forms packs and coordinates pursuit', () => {
  let eco = createEcosystem({seed: 8});
  const pack = eco.entities.filter(e => e.species === 'EmberStalker').slice(0, 2);
  pack[0].position={x:0,z:0}; pack[1].position={x:2,z:0};
  const prey = findEntity(eco, 'mossback-0'); prey.position={x:6,z:0};
  eco = tickEcosystem(eco,{player:{x:60,z:60},dt:1});
  assert.ok(findEntity(eco,pack[0].id).packId);
  assert.equal(findEntity(eco,pack[1].id).packId, findEntity(eco,pack[0].id).packId);
  assert.ok(['stalking','hunting','pack-hunting','territorial'].includes(findEntity(eco,pack[0].id).state));
});

test('food web reproduces healthy prey and suppresses populations under scarcity', () => {
  let eco = createEcosystem({seed: 5});
  const prey = findEntity(eco,'mossback-0');
  const mate = findEntity(eco,'mossback-1');
  prey.position={x:0,z:0}; mate.position={x:1,z:0}; prey.energy=1; mate.energy=1;
  const before = eco.entities.length;
  for(let i=0;i<20;i++) eco=tickEcosystem(eco,{player:{x:80,z:80},dt:1});
  assert.ok(eco.entities.length>before);
  const stressed = createEcosystem({seed:5});
  for(const e of stressed.entities) if(e.kind==='flora') e.population=.03;
  const stressedBefore=stressed.entities.length;
  let stressedAfter=stressed;
  for(let i=0;i<20;i++) stressedAfter=tickEcosystem(stressedAfter,{player:{x:80,z:80},dt:1});
  assert.ok(stressedAfter.entities.length<=stressedBefore+1);
});

test('migration and territorial conflict move species and resolve dominance', () => {
  let eco=createEcosystem({seed:12});
  const p0=findEntity(eco,'emberstalker-0'); const p1=findEntity(eco,'emberstalker-1');
  p0.position={x:0,z:0}; p1.position={x:1,z:0}; p0.energy=.1; p1.energy=.9;
  for(const e of eco.entities) if(e.kind==='flora') e.population=.04;
  eco=tickEcosystem(eco,{player:{x:80,z:80},dt:5});
  assert.ok(findEntity(eco,p0.id).territory.conflicts>=0);
  assert.ok(findEntity(eco,p0.id).migration.pressure>=0);
});

test('symbiosis and environmental events alter ecological state without cheating', () => {
  let eco=createEcosystem({seed:33});
  const moss=findEntity(eco,'mossback-0');
  const fern=findEntity(eco,'lumenfern-0');
  const bonded=bindSymbiosis(eco,moss.id,fern.id,'mutualism');
  assert.equal(findEntity(bonded,moss.id).symbioses.length,1);
  const evented=triggerEnvironmentalEvent(bonded,{type:'aether-bloom',duration:10,intensity:.8});
  assert.equal(evented.events.at(-1).type,'aether-bloom');
  assert.ok(evented.weather.bloomIntensity>.5);
});

test('Apex Beasts and Astral Titans influence territory and recognize celestial signatures', () => {
  let eco=createEcosystem({seed:99});
  const apex=createApexBeast(eco,{species:'EmberStalker',x:10,z:10});
  const titan=createAstralTitan(eco,{x:40,z:-20});
  assert.equal(apex.tier,'Apex Beast');
  assert.equal(titan.tier,'Astral Titan');
  const affected=tickEcosystem({...eco,entities:[...eco.entities,apex,titan]},{player:{x:10,z:10},dt:1,celestial:{sign:'Aries',birthStar:'Hamal'}});
  assert.ok(affected.entities.some(e=>e.id===titan.id));
  assert.ok(findEntity(affected,titan.id).astralPresence>0);
  assert.ok(findEntity(affected,apex.id).territory.radius>=28);
});

test('master graphics profiles translate biology into luminous material and silhouette parameters', async () => {
  const {visualProfileFromPhenotype} = await import('../src/render/visual-profile.js');
  const profile = visualProfileFromPhenotype({mass:2,armor:1.1,senses:1.7,luminescence:1.8,limbCount:6});
  assert.ok(profile.bodyScale.x > 1);
  assert.ok(profile.glowIntensity > 2);
  assert.equal(profile.limbCount, 6);
  assert.ok(profile.rimIntensity > 0);
});

test('celestial palette stays deterministic and has atmospheric layers', async () => {
  const {celestialPalette} = await import('../src/render/visual-profile.js');
  const a = celestialPalette({sign:'Aries', element:'Fire'});
  const b = celestialPalette({sign:'Aries', element:'Fire'});
  assert.deepEqual(a,b);
  assert.ok(a.sky && a.nebula && a.aura && a.emissive);
});

test('master graphics profiles respond to ecosystem state and celestial pressure', async () => {
  const { bioluminescenceProfile, environmentalVisualProfile, tierVisualProfile } = await import('../src/render/visual-profile.js');
  const calm = bioluminescenceProfile({ state:'idle', phenotype:{luminescence:1} }, { bloomIntensity:0.2, stormIntensity:0, astralPressure:0.1 });
  const storm = bioluminescenceProfile({ state:'hunting', phenotype:{luminescence:1} }, { bloomIntensity:0.8, stormIntensity:0.9, astralPressure:0.7 });
  assert.ok(storm.intensity > calm.intensity);
  assert.ok(storm.pulseSpeed > calm.pulseSpeed);
  const event = environmentalVisualProfile({ bloomIntensity:0.9, stormIntensity:0.7, voidIntensity:0.3, luminosity:0.4, astralPressure:0.8 });
  assert.ok(event.fogDensity > 0);
  assert.ok(event.particleEnergy > 0);
  assert.ok(tierVisualProfile('Astral Titan').scale > tierVisualProfile('Apex Beast').scale);
});
