const PALETTES = Object.freeze({
  Fire: {sky:0x070b1c, nebula:0x3a123b, aura:0xff6f4e, emissive:0xffb06a},
  Earth: {sky:0x06101a, nebula:0x153d42, aura:0x8ce3a7, emissive:0x9fffc7},
  Air: {sky:0x071322, nebula:0x263f69, aura:0x8ad9ff, emissive:0xc4f1ff},
  Water: {sky:0x04101b, nebula:0x123d55, aura:0x5ed8ff, emissive:0x8df5ff}
});
export function visualProfileFromPhenotype(p={}){return{
 bodyScale:{x:.78+(p.mass??1)*.62,y:.62+(p.armor??.5)*.3,z:.95+(p.mass??1)*.82},
 glowIntensity:1.2+(p.luminescence??.5)*2.4,
 rimIntensity:.45+(p.senses??.5)*.9,
 armorDensity:.25+(p.armor??.5)*.75,
 limbCount:p.limbCount??4,
 eyeScale:.8+(p.senses??.5)*.5
};}
export function celestialPalette(c={}){return PALETTES[c.element]||PALETTES.Air;}

const STATE_PULSE = Object.freeze({
  idle: 1,
  foraging: 1.08,
  alert: 1.2,
  fleeing: 1.35,
  stalking: 1.3,
  hunting: 1.55,
  'pack-hunting': 1.72,
  feeding: 1.15,
  resting: 0.78,
  territorial: 1.42,
  migrating: 1.18,
  bonded: 1.28
});

export function bioluminescenceProfile(entity={}, weather={}) {
  const phenotype = entity.phenotype || {};
  const statePulse = STATE_PULSE[entity.state] || 1;
  const environmental = 1 + (weather.bloomIntensity ?? 0) * 0.45 + (weather.astralPressure ?? 0) * 0.35 + (weather.stormIntensity ?? 0) * 0.25;
  return {
    intensity: (0.8 + (phenotype.luminescence ?? 0.5) * 1.8) * statePulse * environmental,
    pulseSpeed: 0.7 + statePulse * 0.65 + (weather.stormIntensity ?? 0) * 0.8,
    bloom: 0.12 + (phenotype.luminescence ?? 0.5) * 0.16 + (weather.bloomIntensity ?? 0) * 0.2
  };
}

export function environmentalVisualProfile(weather={}) {
  const storm = weather.stormIntensity ?? 0;
  const voidIntensity = weather.voidIntensity ?? 0;
  const pressure = weather.astralPressure ?? 0;
  return {
    fogDensity: 0.012 + storm * 0.018 + voidIntensity * 0.009,
    particleEnergy: 0.25 + storm * 0.7 + pressure * 0.9 + (weather.bloomIntensity ?? 0) * 0.45,
    lightShafts: 0.15 + (weather.luminosity ?? 0.5) * 0.35 + pressure * 0.3,
    stormCharge: storm * 1.4 + pressure * 0.5
  };
}

export function tierVisualProfile(tier='creature') {
  if (tier === 'Astral Titan') return { scale: 5.8, aura: 2.4, atmospheric: 1.9, particleRadius: 14 };
  if (tier === 'Apex Beast') return { scale: 2.7, aura: 1.35, atmospheric: 0.9, particleRadius: 6 };
  return { scale: 1, aura: 0.65, atmospheric: 0.35, particleRadius: 2 };
}
