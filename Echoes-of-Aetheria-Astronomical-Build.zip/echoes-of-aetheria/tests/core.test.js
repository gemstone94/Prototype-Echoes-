import test from 'node:test';
import assert from 'node:assert/strict';
import { zodiacFromBirth, createPlayer, recordMemory, unlockGlyph, meditate, buildConstellation, legendaryAscend, predatorProfile, combineRunes } from '../src/simulation/core.js';

test('birth date chooses the correct Martian lineage',()=>{assert.equal(zodiacFromBirth(3,21),'Aries');assert.equal(createPlayer(3,21).species,'Emberhorn');assert.equal(createPlayer(12,25).species,'Cragwalker')});
test('memory and glyphs drive evolution',()=>{let p=createPlayer(3,21);p=recordMemory(p,{type:'hunt',target:'Mossback'});p=unlockGlyph(p,'predator',"Hunter's Pulse");p=meditate(p);assert.equal(p.stage,1);assert.equal(p.memories.length,1)});
test('rune combinations unlock higher mutations',()=>{assert.deepEqual(combineRunes(['predator','astral']),{name:'Astral Hunt',runes:['predator','astral'],rarity:'rare'})});
test('constellation then ascension',()=>{let p=createPlayer(3,21);p=unlockGlyph(p,'predator','Hunter');for(let i=0;i<5;i++)p=meditate(p);p=buildConstellation(p);assert.equal(p.constellation.length,7);p=legendaryAscend(p);assert.equal(p.stage,6)});
test('predator tiers escalate in scale and threat',()=>{assert.ok(predatorProfile('Astral Titan').massScale>predatorProfile('Apex Beast').massScale);assert.equal(predatorProfile('Astral Titan').danger,1);assert.equal(predatorProfile('Astral Titan').beauty,1)});
