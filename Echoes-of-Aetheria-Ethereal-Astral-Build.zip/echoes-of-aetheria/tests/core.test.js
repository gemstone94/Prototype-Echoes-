import test from 'node:test';
import assert from 'node:assert/strict';
import { zodiacFromBirth, createPlayer, recordMemory, unlockGlyph, meditate, buildConstellation, legendaryAscend, predatorProfile, combineRunes, RUNE, STAGE, deriveMutation, ecologicalResonance } from '../src/simulation/core.js';

test('birth date chooses the correct Martian lineage',()=>{assert.equal(zodiacFromBirth(3,21),'Aries');assert.equal(createPlayer(3,21).species,'Emberhorn');assert.equal(createPlayer(12,25).species,'Cragwalker')});
test('memory and glyphs drive evolution',()=>{let p=createPlayer(3,21);p=recordMemory(p,{type:'hunt',target:'Mossback'});p=unlockGlyph(p,'predator',"Hunter's Pulse");p=meditate(p);assert.equal(p.stage,1);assert.equal(p.memories.length,1)});
test('rune combinations unlock higher mutations',()=>{assert.deepEqual(combineRunes(['predator','astral']),{name:'Astral Hunt',runes:['predator','astral'],rarity:'rare'})});
test('constellation then ascension',()=>{let p=createPlayer(3,21);p=unlockGlyph(p,'predator','Hunter');for(let i=0;i<5;i++)p=meditate(p);p=buildConstellation(p);assert.equal(p.constellation.length,7);p=legendaryAscend(p);assert.equal(p.stage,6)});
test('predator tiers escalate in scale and threat',()=>{assert.ok(predatorProfile('Astral Titan').massScale>predatorProfile('Apex Beast').massScale);assert.equal(predatorProfile('Astral Titan').danger,1);assert.equal(predatorProfile('Astral Titan').beauty,1)});

test('celestial signature is deterministic and astrological', () => {
  const p = createPlayer(3,21);
  assert.equal(p.sign, 'Aries');
  assert.equal(p.celestial.element, 'fire');
  assert.equal(p.celestial.modality, 'cardinal');
  assert.equal(p.celestial.lunarAffinity, 'full');
  assert.ok(p.celestial.birthStar);
});

test('adaptation profile derives a mutation from rune history and biome exposure', () => {
  let p = createPlayer(3,21);
  p = recordMemory(p,{type:'hunt',target:'Mossback',biome:'Glowfen'});
  p = unlockGlyph(p,RUNE.PREDATOR,"Hunter's Pulse");
  p = unlockGlyph(p,RUNE.STALKER,'Ashstep');
  const mutation = deriveMutation(p);
  assert.equal(mutation.name, 'Apex Pursuer');
  assert.ok(mutation.physical.includes('crystalline shoulder plates'));
  assert.equal(mutation.biomeAffinity, 'Glowfen');
});

test('void resonance carries a measurable ecological cost', () => {
  let p = createPlayer(3,21);
  p = unlockGlyph(p,RUNE.VOID,'Null Resonance');
  p = unlockGlyph(p,RUNE.SYMBIOSIS,'Pack Bond');
  const ecology = ecologicalResonance(p);
  assert.ok(ecology.voidInstability > 0);
  assert.ok(ecology.symbiosisPenalty > 0);
});

test('constellation completes before legendary ascension and records pathway', () => {
  let p = createPlayer(3,21);
  p = unlockGlyph(p,RUNE.PREDATOR,'Hunter');
  p = { ...p, stage: STAGE.CONSTELLATION };
  p = buildConstellation(p);
  p = legendaryAscend(p);
  assert.equal(p.stage, STAGE.ASCENSION);
  assert.equal(p.ascensionPathway, 'Apex Emberborn');
  assert.equal(p.constellation.length, 7);
});

test('all twelve lineages have a celestial ascension identity', () => {
  const dates=[[3,21],[4,21],[5,21],[6,21],[7,23],[8,23],[9,23],[10,23],[11,23],[12,22],[1,21],[2,20]];
  for(const [month,day] of dates){
    let p=createPlayer(month,day);
    assert.ok(p.celestial.birthStar);
    p={...p,stage:STAGE.CONSTELLATION,constellation:['a','b','c','d','e','f','g']};
    assert.ok(legendaryAscend(p).ascensionPathway);
  }
});
