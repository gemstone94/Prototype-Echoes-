export class MeditationOverlay {
  constructor(private readonly uiRoot: HTMLElement) {}

  play(onComplete: () => void): void {
    const overlay = document.createElement('div');
    overlay.className = 'overlay';
    overlay.innerHTML = `<section class="awakening-card meditation"><p class="eyebrow">EVOLUTION MEDITATION</p><div class="starburst">✦</div><h1>Remember.</h1><p class="lede">The hunt. The breath. The moment the world became quiet.</p><p class="fine">Your body is listening to what you survived.</p><button id="evolve-now">Let the glyph grow</button></section>`;
    this.uiRoot.appendChild(overlay);
    overlay.querySelector<HTMLButtonElement>('#evolve-now')!.onclick = () => { overlay.remove(); onComplete(); };
  }
}
