import type { CelestialLineage } from '../simulation/identity/types.js';
import type { PlayerState } from '../simulation/progression/types.js';
import { validateBirthDate } from './birth.js';

export class AppUI {
  private readonly root: HTMLElement;
  private readonly overlay: HTMLElement;
  private readonly hud: HTMLElement;
  private readonly prompt: HTMLElement;

  constructor(root = document.getElementById('ui')!) {
    this.root = root;
    this.root.innerHTML = '';
    this.overlay = document.createElement('div'); this.overlay.className = 'overlay';
    this.hud = document.createElement('div'); this.hud.className = 'hud';
    this.prompt = document.createElement('div'); this.prompt.className = 'prompt';
    this.root.append(this.overlay, this.hud, this.prompt);
  }

  renderBirthEntry(onSubmit: (month: number, day: number) => void): void {
    this.overlay.innerHTML = `<section class="awakening-card"><p class="eyebrow">ECHOES OF AETHERIA</p><h1>Awaken your constellation.</h1><p class="lede">Your birth is the doorway. Your survival writes the rest.</p><div class="date-row"><label>Month<select id="birth-month">${Array.from({length:12}, (_, i) => `<option value="${i+1}">${i+1}</option>`).join('')}</select></label><label>Day<input id="birth-day" type="number" min="1" max="31" value="1" /></label></div><button id="awaken">Awaken</button><p class="fine">Birth month and day determine your ancestral Martian lineage.</p></section>`;
    const button = this.overlay.querySelector<HTMLButtonElement>('#awaken')!;
    button.onclick = () => {
      const month = Number((this.overlay.querySelector('#birth-month') as HTMLSelectElement).value);
      const day = Number((this.overlay.querySelector('#birth-day') as HTMLInputElement).value);
      if (!validateBirthDate(month, day)) { this.showPrompt('That date cannot awaken a constellation.'); return; }
      onSubmit(month, day);
    };
  }

  showAwakening(lineage: CelestialLineage): void {
    this.overlay.innerHTML = `<section class="awakening-card awakening-sequence"><p class="eyebrow">THE ASTRAL AWAKENING</p><div class="starburst">✦</div><p class="eyebrow">${lineage.zodiac.toUpperCase()}</p><h1>${lineage.name}</h1><p class="lede">The First Flame remembers you.</p><p class="gift">Starting Gift · <strong>${lineage.startingGift}</strong></p><button id="enter-world">Enter Aetheria</button></section>`;
  }

  bindEnterWorld(onEnter: () => void): void { this.overlay.querySelector<HTMLButtonElement>('#enter-world')?.addEventListener('click', () => { this.overlay.classList.add('hidden'); onEnter(); }); }

  showHud(state: PlayerState): void {
    this.hud.innerHTML = `<div class="status"><span>♈ EMBERHORN</span><span>STAGE ${state.stage}</span><span>${state.unlockedGlyphs.length ? '◈ HUNTER\'S PULSE' : 'UNAWAKENED GLYPH'}</span></div>`;
  }

  showPrompt(text: string): void { this.prompt.textContent = text; this.prompt.classList.toggle('visible', Boolean(text)); }
  hidePrompt(): void { this.showPrompt(''); }
  hideOverlay(): void { this.overlay.classList.add('hidden'); }
  showOverlay(html: string): void { this.overlay.innerHTML = html; this.overlay.classList.remove('hidden'); }
}
