import { resolveZodiac } from '../simulation/identity/zodiac.js';

export function validateBirthDate(month: number, day: number): boolean {
  try { resolveZodiac(month, day); return true; } catch { return false; }
}
