import { recordExperience } from '../progression/evolution.js';
import type { PlayerState } from '../progression/types.js';

export function completeHunt(state: PlayerState, preyId: string): PlayerState {
  if (!preyId.trim()) throw new Error('A prey id is required');
  return recordExperience(state, { type: 'hunt-complete', target: preyId });
}
