import type { RuneFamily } from '../identity/types.js';
import type { EvolutionDefinition, ExperienceEvent, PlayerState } from './types.js';

export const ariesEvolutions: EvolutionDefinition[] = [
  { id: 'hunter-pulse', stage: 1, label: "Hunter's Pulse", runeRequirements: ['predator'] },
  { id: 'bloodfire', stage: 2, label: 'Bloodfire', runeRequirements: ['predator', 'survival'] },
  { id: 'ashstalker', stage: 2, label: 'Ashstalker', runeRequirements: ['predator', 'stalker'] },
  { id: 'packfire', stage: 2, label: 'Packfire', runeRequirements: ['predator', 'symbiosis'] },
  { id: 'apex-pursuer', stage: 3, label: 'Apex Pursuer', runeRequirements: ['predator', 'stalker', 'survival'] },
  { id: 'aries-constellation', stage: 4, label: 'Full Constellation: Aries', runeRequirements: ['predator'] },
  { id: 'apex-emberborn', stage: 5, label: 'Apex Emberborn', runeRequirements: ['predator'] },
];

export function createPlayerState(lineageId: string): PlayerState {
  return { lineageId, stage: 0, unlockedGlyphs: [], memory: [], pendingEvolution: null, constellationAwakened: false };
}

export function recordExperience(state: PlayerState, event: ExperienceEvent): PlayerState {
  const memory = [...state.memory, event];
  const unlockedGlyphs = [...state.unlockedGlyphs];
  let pendingEvolution = state.pendingEvolution;
  if (state.lineageId === 'emberhorn' && event.type === 'hunt-complete' && !unlockedGlyphs.includes('hunter-pulse')) {
    unlockedGlyphs.push('hunter-pulse');
    pendingEvolution = 'hunter-pulse';
  }
  return { ...state, memory, unlockedGlyphs, pendingEvolution };
}

export function getNextEvolution(state: PlayerState): EvolutionDefinition | null {
  const definitions = state.lineageId === 'emberhorn' ? ariesEvolutions : [];
  return definitions.find((evolution) => evolution.id === state.pendingEvolution) ?? null;
}

export function hasRune(state: PlayerState, rune: RuneFamily): boolean {
  return state.lineageId === 'emberhorn' && (rune === 'predator' || state.unlockedGlyphs.includes(rune));
}
