import type { RuneFamily } from '../identity/types.js';

export interface ExperienceEvent {
  type: 'hunt-complete' | 'exploration' | 'herbal-discovery' | 'symbiosis' | 'survival';
  target?: string;
}

export interface EvolutionDefinition {
  id: string;
  stage: number;
  label: string;
  runeRequirements: RuneFamily[];
}

export interface PlayerState {
  lineageId: string;
  stage: number;
  unlockedGlyphs: string[];
  memory: ExperienceEvent[];
  pendingEvolution: string | null;
  constellationAwakened: boolean;
}
