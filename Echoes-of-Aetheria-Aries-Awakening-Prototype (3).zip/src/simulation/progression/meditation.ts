import { getNextEvolution } from './evolution.js';
import type { PlayerState } from './types.js';

export function beginMeditation(state: PlayerState): PlayerState {
  if (!state.pendingEvolution) throw new Error('Meditation is unavailable');
  return { ...state };
}

export function completeMeditation(state: PlayerState): PlayerState {
  const evolution = getNextEvolution(state);
  if (!evolution) throw new Error('No pending evolution');
  return {
    ...state,
    stage: Math.max(state.stage, evolution.stage),
    pendingEvolution: null,
    constellationAwakened: state.constellationAwakened || evolution.id === 'aries-constellation',
  };
}
