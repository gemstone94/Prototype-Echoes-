import { getLineageForZodiac } from './lineages.js';
import { resolveZodiac } from './zodiac.js';
import { createPlayerState } from '../progression/evolution.js';
import type { PlayerState } from '../progression/types.js';

export function createPlayerFromBirth(month: number, day: number): PlayerState {
  const sign = resolveZodiac(month, day);
  return createPlayerState(getLineageForZodiac(sign).id);
}
