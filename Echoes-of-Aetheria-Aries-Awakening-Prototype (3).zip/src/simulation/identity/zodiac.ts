import type { ZodiacSign } from './types.js';

const ranges: Array<[ZodiacSign, number, number, number, number]> = [
  ['aries', 3, 21, 4, 19], ['taurus', 4, 20, 5, 20], ['gemini', 5, 21, 6, 20],
  ['cancer', 6, 21, 7, 22], ['leo', 7, 23, 8, 22], ['virgo', 8, 23, 9, 22],
  ['libra', 9, 23, 10, 22], ['scorpio', 10, 23, 11, 21], ['sagittarius', 11, 22, 12, 21],
  ['capricorn', 12, 22, 12, 31], ['capricorn', 1, 1, 1, 19], ['aquarius', 1, 20, 2, 18],
  ['pisces', 2, 19, 3, 20],
];

function ordinal(month: number, day: number): number {
  const days = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (!Number.isInteger(month) || !Number.isInteger(day) || month < 1 || month > 12 || day < 1 || day > days[month - 1]) {
    throw new RangeError('Birth month/day is invalid');
  }
  return days.slice(0, month - 1).reduce((sum, value) => sum + value, 0) + day;
}

export function resolveZodiac(month: number, day: number): ZodiacSign {
  const value = ordinal(month, day);
  for (const [sign, startMonth, startDay, endMonth, endDay] of ranges) {
    const start = ordinal(startMonth, startDay);
    const end = ordinal(endMonth, endDay);
    if (start <= end ? value >= start && value <= end : value >= start || value <= end) return sign;
  }
  throw new Error('Unable to resolve zodiac sign');
}
