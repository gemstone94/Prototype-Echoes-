import type { CelestialLineage, ZodiacSign } from './types.js';

const lineageData: Record<ZodiacSign, CelestialLineage> = {
  aries: { id: 'emberhorn', zodiac: 'aries', name: 'Emberhorn', startingGift: 'First Strike', naturalRunes: ['predator', 'survival'], secondaryAffinity: 'stalker', rareAffinity: 'symbiosis', dangerousAffinity: 'void' },
  taurus: { id: 'stonebloom', zodiac: 'taurus', name: 'Stonebloom', startingGift: 'Rooted', naturalRunes: ['survival', 'herbal'], secondaryAffinity: 'symbiosis', rareAffinity: 'stalker', dangerousAffinity: 'void' },
  gemini: { id: 'twin-echo', zodiac: 'gemini', name: 'Twin-Echo', startingGift: 'Echo Memory', naturalRunes: ['stalker', 'astral'], secondaryAffinity: 'symbiosis', rareAffinity: 'void', dangerousAffinity: 'predator' },
  cancer: { id: 'tideshell', zodiac: 'cancer', name: 'Tideshell', startingGift: 'Protective Instinct', naturalRunes: ['survival', 'symbiosis'], secondaryAffinity: 'herbal', rareAffinity: 'astral', dangerousAffinity: 'void' },
  leo: { id: 'sunmane', zodiac: 'leo', name: 'Sunmane', startingGift: 'Resonant Command', naturalRunes: ['symbiosis', 'predator'], secondaryAffinity: 'astral', rareAffinity: 'survival', dangerousAffinity: 'void' },
  virgo: { id: 'spore-sage', zodiac: 'virgo', name: 'Spore-Sage', startingGift: 'Botanical Analysis', naturalRunes: ['herbal', 'astral'], secondaryAffinity: 'survival', rareAffinity: 'symbiosis', dangerousAffinity: 'void' },
  libra: { id: 'harmonic', zodiac: 'libra', name: 'Harmonic', startingGift: 'Shared Equilibrium', naturalRunes: ['symbiosis', 'astral'], secondaryAffinity: 'herbal', rareAffinity: 'predator', dangerousAffinity: 'void' },
  scorpio: { id: 'velistinger', zodiac: 'scorpio', name: 'Velistinger', startingGift: 'Venom Sense', naturalRunes: ['predator', 'stalker'], secondaryAffinity: 'herbal', rareAffinity: 'void', dangerousAffinity: 'symbiosis' },
  sagittarius: { id: 'starstrider', zodiac: 'sagittarius', name: 'Starstrider', startingGift: 'Far Sight', naturalRunes: ['astral', 'stalker'], secondaryAffinity: 'survival', rareAffinity: 'symbiosis', dangerousAffinity: 'void' },
  capricorn: { id: 'cragwalker', zodiac: 'capricorn', name: 'Cragwalker', startingGift: 'Sure Grip', naturalRunes: ['survival', 'stalker'], secondaryAffinity: 'herbal', rareAffinity: 'astral', dangerousAffinity: 'void' },
  aquarius: { id: 'stormmind', zodiac: 'aquarius', name: 'Stormmind', startingGift: 'Current Reader', naturalRunes: ['astral', 'survival'], secondaryAffinity: 'symbiosis', rareAffinity: 'void', dangerousAffinity: 'predator' },
  pisces: { id: 'dreamswimmer', zodiac: 'pisces', name: 'Dreamswimmer', startingGift: 'Dream Connection', naturalRunes: ['astral', 'symbiosis'], secondaryAffinity: 'herbal', rareAffinity: 'void', dangerousAffinity: 'stalker' },
};

export function getLineageForZodiac(sign: ZodiacSign): CelestialLineage {
  return lineageData[sign];
}
