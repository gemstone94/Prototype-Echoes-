export type ZodiacSign =
  | 'aries' | 'taurus' | 'gemini' | 'cancer' | 'leo' | 'virgo'
  | 'libra' | 'scorpio' | 'sagittarius' | 'capricorn' | 'aquarius' | 'pisces';

export type RuneFamily = 'predator' | 'stalker' | 'herbal' | 'symbiosis' | 'survival' | 'astral' | 'void';

export interface CelestialLineage {
  id: string;
  zodiac: ZodiacSign;
  name: string;
  startingGift: string;
  naturalRunes: RuneFamily[];
  secondaryAffinity: RuneFamily;
  rareAffinity: RuneFamily;
  dangerousAffinity: RuneFamily;
}
