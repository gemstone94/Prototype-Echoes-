import { resolveZodiac } from './simulation/identity/zodiac.js';
import { getLineageForZodiac } from './simulation/identity/lineages.js';
import { createPlayerState, recordExperience } from './simulation/progression/evolution.js';
import { beginMeditation, completeMeditation } from './simulation/progression/meditation.js';
import type { PlayerState } from './simulation/progression/types.js';
import { createInputMap } from './input/actions.js';
import { GameRenderer } from './render/app/GameRenderer.js';
import { AppUI } from './ui/AppUI.js';
import { MeditationOverlay } from './ui/MeditationOverlay.js';
import './ui/styles.css';

const gameRoot = document.getElementById('game')!;
const canvas = document.createElement('canvas');
gameRoot.appendChild(canvas);
const renderer = new GameRenderer(canvas);
const ui = new AppUI();
const meditation = new MeditationOverlay(document.getElementById('ui')!);
const input = createInputMap();
const keys = new Set<string>();
let state: PlayerState | null = null;
let player = { x: 0, z: 0 };
let running = false;
let huntDone = false;

ui.renderBirthEntry((month, day) => {
  const sign = resolveZodiac(month, day);
  const lineage = getLineageForZodiac(sign);
  state = createPlayerState(lineage.id);
  ui.showAwakening(lineage);
  ui.bindEnterWorld(() => { running = true; ui.showHud(state!); ui.showPrompt('WASD to move · E near a creature to hunt'); });
});

document.addEventListener('keydown', (event) => keys.add(event.code));
document.addEventListener('keyup', (event) => keys.delete(event.code));

function update(dt: number): void {
  if (!state || !running) return;
  let dx = 0, dz = 0;
  if (keys.has(input.moveForward)) dz -= 1;
  if (keys.has(input.moveBackward)) dz += 1;
  if (keys.has(input.moveLeft)) dx -= 1;
  if (keys.has(input.moveRight)) dx += 1;
  const length = Math.hypot(dx, dz) || 1;
  if (dx || dz) {
    const speed = 2.6 * dt;
    dx = (dx / length) * speed; dz = (dz / length) * speed;
    player.x += dx; player.z += dz; renderer.move(dx, dz);
  }
  const prey = { x: 2.5, z: -3 };
  const distance = Math.hypot(player.x - prey.x, player.z - prey.z);
  if (!huntDone && distance < 1.8) {
    ui.showPrompt('Press E · hunt the mossback');
    if (keys.has(input.interact)) {
      huntDone = true;
      state = recordExperience(state, { type: 'hunt-complete', target: 'mossback' });
      ui.showHud(state); ui.showPrompt('Hunter\'s Pulse awakens. Press M to meditate.');
    }
  } else if (!huntDone) {
    ui.showPrompt('WASD to move · E near a creature to hunt');
  } else if (keys.has(input.meditate) && state.pendingEvolution) {
    const ready = beginMeditation(state);
    keys.delete(input.meditate);
    ui.hidePrompt();
    meditation.play(() => { state = completeMeditation(ready); ui.showHud(state); ui.showPrompt('The Hunter\'s Pulse is alive. Your body remembers.'); });
  }
  renderer.sync(state);
}

let previous = performance.now();
function frame(now: number): void {
  const dt = Math.min((now - previous) / 1000, 0.05); previous = now;
  update(dt); requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
