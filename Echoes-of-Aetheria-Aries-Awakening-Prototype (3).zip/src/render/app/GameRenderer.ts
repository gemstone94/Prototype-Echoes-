import type { PlayerState } from '../../simulation/progression/types.js';
import { Emberhorn, type RenderPart } from '../objects/Emberhorn.js';
import { getWorldParts } from '../objects/World.js';
import { getAriesConstellationParts } from '../objects/Constellation.js';

function mat4Perspective(out: Float32Array, fov: number, aspect: number, near: number, far: number): void {
  const f = 1 / Math.tan(fov / 2), nf = 1 / (near - far);
  out.set([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0]);
}
function mat4LookAt(out: Float32Array, eye: [number, number, number], target: [number, number, number]): void {
  let zx = eye[0] - target[0], zy = eye[1] - target[1], zz = eye[2] - target[2];
  let zlen = Math.hypot(zx, zy, zz); zx /= zlen; zy /= zlen; zz /= zlen;
  let xx = -zz, xy = 0, xz = zx;
  const xlen = Math.hypot(xx, xy, xz); xx /= xlen; xy /= xlen; xz /= xlen;
  const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
  out.set([xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0, -(xx*eye[0]+xy*eye[1]+xz*eye[2]), -(yx*eye[0]+yy*eye[1]+yz*eye[2]), -(zx*eye[0]+zy*eye[1]+zz*eye[2]), 1]);
}
function mat4Multiply(out: Float32Array, a: Float32Array, b: Float32Array): void {
  for (let c=0;c<4;c++) for (let r=0;r<4;r++) out[c*4+r] = a[r]*b[c*4] + a[4+r]*b[c*4+1] + a[8+r]*b[c*4+2] + a[12+r]*b[c*4+3];
}

export class GameRenderer {
  private readonly canvas: HTMLCanvasElement;
  private readonly gl: WebGLRenderingContext;
  private readonly program: WebGLProgram;
  private readonly position: number;
  private readonly color: WebGLUniformLocation | null;
  private readonly matrix: WebGLUniformLocation | null;
  private readonly buffer: WebGLBuffer;
  private readonly emberhorn = new Emberhorn();
  private camera: [number, number, number] = [0, 2.5, 6];
  private player: [number, number, number] = [0, 0, 0];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const gl = canvas.getContext('webgl', { antialias: true });
    if (!gl) throw new Error('WebGL is required for the Aetheria prototype');
    this.gl = gl;
    const vertex = gl.createShader(gl.VERTEX_SHADER)!;
    gl.shaderSource(vertex, 'attribute vec3 aPosition; uniform mat4 uMatrix; void main(){gl_Position=uMatrix*vec4(aPosition,1.0);}'); gl.compileShader(vertex);
    const fragment = gl.createShader(gl.FRAGMENT_SHADER)!;
    gl.shaderSource(fragment, 'precision mediump float; uniform vec3 uColor; void main(){gl_FragColor=vec4(uColor,1.0);}'); gl.compileShader(fragment);
    const program = gl.createProgram()!;
    gl.attachShader(program, vertex); gl.attachShader(program, fragment); gl.linkProgram(program);
    this.program = program;
    this.position = gl.getAttribLocation(program, 'aPosition');
    this.color = gl.getUniformLocation(program, 'uColor');
    this.matrix = gl.getUniformLocation(program, 'uMatrix');
    this.buffer = gl.createBuffer()!;
    gl.enable(gl.DEPTH_TEST);
  }

  resize(): void {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.floor(this.canvas.clientWidth * dpr), height = Math.floor(this.canvas.clientHeight * dpr);
    if (this.canvas.width !== width || this.canvas.height !== height) { this.canvas.width = width; this.canvas.height = height; }
    this.gl.viewport(0, 0, width, height);
  }

  move(dx: number, dz: number): void {
    this.player[0] += dx; this.player[2] += dz;
    this.camera[0] = this.player[0]; this.camera[2] = this.player[2] + 6;
  }

  sync(state: PlayerState): void {
    this.draw(state.stage >= 1);
  }

  private draw(evolved: boolean): void {
    const gl = this.gl;
    this.resize();
    gl.clearColor(.015, .02, .035, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.useProgram(this.program);
    const projection = new Float32Array(16); mat4Perspective(projection, Math.PI / 3, this.canvas.width / this.canvas.height, .1, 100);
    const view = new Float32Array(16); mat4LookAt(view, this.camera, [this.player[0], 1, this.player[2] - 2]);
    const viewProjection = new Float32Array(16); mat4Multiply(viewProjection, projection, view);
    gl.uniformMatrix4fv(this.matrix, false, viewProjection);
    for (const part of getWorldParts()) this.drawCube(part, this.camera);
    for (const part of this.emberhorn.getParts(evolved)) this.drawCube({ ...part, x: part.x + this.player[0], z: part.z + this.player[2] }, this.camera);
    for (const part of getAriesConstellationParts(evolved)) this.drawCube({ ...part, x: part.x + this.player[0], z: part.z + this.player[2] }, this.camera);
  }

  private drawCube(part: RenderPart, camera: [number, number, number]): void {
    const gl = this.gl;
    const x = part.x, y = part.y, z = part.z;
    const sx = part.sx / 2, sy = part.sy / 2, sz = part.sz / 2;
    const verts = new Float32Array([
      x-sx,y-sy,z-sz, x+sx,y-sy,z-sz, x+sx,y+sy,z-sz, x-sx,y+sy,z-sz,
      x-sx,y-sy,z+sz, x+sx,y-sy,z+sz, x+sx,y+sy,z+sz, x-sx,y+sy,z+sz,
    ]);
    const indices = new Uint16Array([0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,2,6,7,2,7,3,0,3,7,0,7,4]);
    const transformed: number[] = [];
    for (const index of indices) transformed.push(verts[index*3], verts[index*3+1], verts[index*3+2]);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(transformed), gl.STREAM_DRAW);
    gl.enableVertexAttribArray(this.position); gl.vertexAttribPointer(this.position, 3, gl.FLOAT, false, 0, 0);
    gl.uniform3fv(this.color, part.color); gl.drawArrays(gl.TRIANGLES, 0, indices.length);
  }
}
