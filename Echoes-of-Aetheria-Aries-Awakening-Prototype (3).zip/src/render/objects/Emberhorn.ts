export interface RenderPart { x: number; y: number; z: number; sx: number; sy: number; sz: number; color: [number, number, number]; }

export class Emberhorn {
  getParts(evolved = false): RenderPart[] {
    const glow = evolved ? [1, 0.55, 0.12] as [number, number, number] : [0.65, 0.18, 0.08] as [number, number, number];
    return [
      { x: 0, y: 1.25, z: 0, sx: .7, sy: 1.0, sz: .45, color: [.16, .18, .2] },
      { x: 0, y: 2.1, z: 0, sx: .55, sy: .55, sz: .42, color: [.2, .22, .24] },
      { x: -.32, y: .48, z: 0, sx: .22, sy: 1.0, sz: .24, color: [.13, .14, .15] },
      { x: .32, y: .48, z: 0, sx: .22, sy: 1.0, sz: .24, color: [.13, .14, .15] },
      { x: -.78, y: 1.28, z: 0, sx: .18, sy: .78, sz: .2, color: [.12, .13, .14] },
      { x: .78, y: 1.28, z: 0, sx: .18, sy: .78, sz: .2, color: [.12, .13, .14] },
      { x: -.2, y: 2.48, z: 0, sx: .14, sy: .6, sz: .14, color: glow },
      { x: .2, y: 2.48, z: 0, sx: .14, sy: .6, sz: .14, color: glow },
      { x: 0, y: 1.25, z: .28, sx: .12, sy: .62, sz: .08, color: glow },
    ];
  }
}
