import type { RenderPart } from './Emberhorn.js';

export function getAriesConstellationParts(active: boolean): RenderPart[] {
  if (!active) return [];
  const stars = [[-.3,1.55,.31],[.05,1.8,.31],[.35,2.02,.31],[.55,2.3,.31],[.25,2.48,.31],[-.05,2.62,.31],[-.38,2.45,.31]];
  return stars.map(([x,y,z]) => ({ x, y, z, sx:.09, sy:.09, sz:.09, color:[1,.72,.28] as [number,number,number] }));
}
