export interface WorldPart { x: number; y: number; z: number; sx: number; sy: number; sz: number; color: [number, number, number]; }

export function getWorldParts(): WorldPart[] {
  return [
    { x: 0, y: -.18, z: 0, sx: 18, sy: .2, sz: 18, color: [.05, .1, .08] },
    { x: 4, y: .55, z: -5, sx: 1.4, sy: 1.1, sz: 1.4, color: [.08, .22, .14] },
    { x: -5, y: .75, z: -7, sx: 1.8, sy: 1.5, sz: 1.8, color: [.12, .18, .1] },
    { x: 2.5, y: .3, z: -3, sx: .65, sy: .6, sz: .65, color: [.55, .22, .08] },
  ];
}
