export interface InputMap {
  moveForward: string;
  moveBackward: string;
  moveLeft: string;
  moveRight: string;
  interact: string;
  meditate: string;
  pause: string;
  confirm: string;
  cancel: string;
  'ability-1': string;
}

export function createInputMap(): InputMap {
  return {
    moveForward: 'KeyW', moveBackward: 'KeyS', moveLeft: 'KeyA', moveRight: 'KeyD',
    interact: 'KeyE', meditate: 'KeyM', pause: 'Escape', confirm: 'Enter', cancel: 'Backspace', 'ability-1': 'Digit1',
  };
}
