import { cpSync, mkdirSync, rmSync, writeFileSync } from 'node:fs';

rmSync('dist', { recursive: true, force: true });
const { execFileSync } = await import('node:child_process');
execFileSync('tsc', { stdio: 'inherit' });
mkdirSync('dist/assets', { recursive: true });
cpSync('src/ui/styles.css', 'dist/src/ui/styles.css');
writeFileSync('dist/index.html', `<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Echoes of Aetheria</title><link rel="stylesheet" href="/src/ui/styles.css"></head><body><div id="game"></div><div id="ui"></div><script type="module" src="/src/main.js"></script></body></html>`);
console.log('Build complete: dist/');
