import { execFileSync } from 'node:child_process';
import { readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

execFileSync('tsc', { stdio: 'inherit' });
function collect(dir) {
  const out = [];
  for (const entry of readdirSync(dir)) {
    const path = join(dir, entry);
    if (statSync(path).isDirectory()) out.push(...collect(path));
    else if (path.endsWith('.test.js')) out.push(path);
  }
  return out;
}
for (const test of collect('dist/tests')) execFileSync(process.execPath, [test], { stdio: 'inherit' });
console.log(`PASS: ${collect('dist/tests').length} test files`);
