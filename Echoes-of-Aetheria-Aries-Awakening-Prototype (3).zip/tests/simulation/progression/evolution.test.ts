import { createPlayerState, recordExperience, getNextEvolution } from '../../../src/simulation/progression/evolution.js';

function equal(actual: unknown, expected: unknown, message: string): void {
  if (actual !== expected) throw new Error(`${message}: expected ${String(expected)}, got ${String(actual)}`);
}

let state = createPlayerState('emberhorn');
state = recordExperience(state, { type: 'hunt-complete', target: 'mossback' });
equal(state.memory.length, 1, 'hunt is recorded in Adaptation Memory');
equal(state.unlockedGlyphs[0], 'hunter-pulse', 'first hunt unlocks Hunter\'s Pulse');
equal(getNextEvolution(state)?.id, 'hunter-pulse', 'Hunter\'s Pulse is the next evolution');
