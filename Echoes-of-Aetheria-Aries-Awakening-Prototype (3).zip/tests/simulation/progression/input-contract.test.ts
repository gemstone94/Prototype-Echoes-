import { createInputMap } from '../../../src/input/actions.js';

const actions = Object.keys(createInputMap()).sort();
const expected = ['ability-1', 'cancel', 'confirm', 'interact', 'meditate', 'moveBackward', 'moveForward', 'moveLeft', 'moveRight', 'pause'].sort();
if (actions.join('|') !== expected.join('|')) throw new Error(`input map mismatch: ${actions.join('|')}`);
