import { createPlayerState, recordExperience } from '../../../src/simulation/progression/evolution.js';
import { beginMeditation, completeMeditation } from '../../../src/simulation/progression/meditation.js';

function equal(actual: unknown, expected: unknown, message: string): void {
  if (actual !== expected) throw new Error(`${message}: expected ${String(expected)}, got ${String(actual)}`);
}

let state = createPlayerState('emberhorn');
let blocked = false;
try { beginMeditation(state); } catch { blocked = true; }
if (!blocked) throw new Error('Meditation must be blocked before Hunter\'s Pulse');
state = recordExperience(state, { type: 'hunt-complete', target: 'mossback' });
state = beginMeditation(state);
state = completeMeditation(state);
equal(state.stage, 1, 'meditation advances Emberhorn to Stage I');
equal(state.pendingEvolution, null, 'meditation consumes the pending evolution');
