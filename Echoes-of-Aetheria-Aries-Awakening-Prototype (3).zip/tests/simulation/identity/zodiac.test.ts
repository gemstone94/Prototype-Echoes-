import { resolveZodiac } from '../../../src/simulation/identity/zodiac.js';
import { getLineageForZodiac } from '../../../src/simulation/identity/lineages.js';

function equal(actual: unknown, expected: unknown, message: string): void {
  if (actual !== expected) throw new Error(`${message}: expected ${String(expected)}, got ${String(actual)}`);
}

equal(resolveZodiac(3, 21), 'aries', 'March 21 is Aries');
equal(resolveZodiac(4, 19), 'aries', 'April 19 is Aries');
equal(resolveZodiac(4, 20), 'taurus', 'April 20 is Taurus');
equal(resolveZodiac(12, 31), 'capricorn', 'December 31 is Capricorn');
equal(resolveZodiac(1, 1), 'capricorn', 'January 1 is Capricorn');
equal(getLineageForZodiac('aries').name, 'Emberhorn', 'Aries lineage is Emberhorn');
