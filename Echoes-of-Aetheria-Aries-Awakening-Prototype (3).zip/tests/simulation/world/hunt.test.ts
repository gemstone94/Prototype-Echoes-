import { completeHunt } from '../../../src/simulation/world/hunt.js';
import { createPlayerState } from '../../../src/simulation/progression/evolution.js';

function equal(actual: unknown, expected: unknown, message: string): void {
  if (actual !== expected) throw new Error(`${message}: expected ${String(expected)}, got ${String(actual)}`);
}

const before = createPlayerState('emberhorn');
const after = completeHunt(before, 'mossback');
equal(after.memory[0]?.type, 'hunt-complete', 'hunt completion records an experience event');
equal(after.memory[0]?.target, 'mossback', 'hunt records the prey id');
