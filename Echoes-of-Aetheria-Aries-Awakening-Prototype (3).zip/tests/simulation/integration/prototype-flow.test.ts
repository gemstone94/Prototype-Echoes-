import { createPlayerFromBirth } from '../../../src/simulation/identity/awakening.js';
import { completeHunt } from '../../../src/simulation/world/hunt.js';
import { beginMeditation, completeMeditation } from '../../../src/simulation/progression/meditation.js';

let state = createPlayerFromBirth(3, 21);
if (state.lineageId !== 'emberhorn') throw new Error('March 21 must awaken Emberhorn');
state = completeHunt(state, 'mossback');
if (!state.unlockedGlyphs.includes('hunter-pulse')) throw new Error('First hunt must awaken Hunter\'s Pulse');
state = beginMeditation(state);
state = completeMeditation(state);
if (state.stage !== 1) throw new Error('Meditation must produce Stage I');
