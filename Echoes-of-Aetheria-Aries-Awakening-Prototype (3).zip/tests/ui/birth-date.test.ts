import { validateBirthDate } from '../../src/ui/birth.js';

if (!validateBirthDate(3, 21)) throw new Error('March 21 should be accepted');
if (validateBirthDate(2, 30)) throw new Error('February 30 should be rejected');
if (!validateBirthDate(4, 19)) throw new Error('April 19 should be accepted');
