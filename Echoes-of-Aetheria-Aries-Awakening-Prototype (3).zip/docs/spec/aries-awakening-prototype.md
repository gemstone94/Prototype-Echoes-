# Aries Awakening Prototype Spec

## Locked product rule

The player never chooses a Martian lineage from a class menu. Their birth month and day awaken the Celestial Martian lineage. Birth determines the ancestral template and Starting Gift; gameplay determines Adaptive Glyphs, evolution branches, Full Constellation, and Legendary Ascension.

## First playable slice

The first fully playable vertical slice is Aries / Emberhorn. The architecture must support all 12 lineages through data-driven definitions, but only Aries is fully implemented in this slice.

## Prototype flow

1. Birth-date entry accepts month and day only.
2. The zodiac resolver maps the date to a constellation lineage.
3. For Aries, show an Astral Awakening sequence and reveal Emberhorn + First Strike.
4. Enter a sparse 3D survival scene.
5. Move the Emberhorn, explore, and encounter a huntable creature.
6. Completing the first hunt records experience in Adaptation Memory and unlocks the first Predator glyph, Hunter's Pulse.
7. Reaching the first evolution threshold opens Meditation.
8. Meditation shows a brief memory montage, glyph ignition, and a visible biological transformation.
9. The prototype ends in the evolved playable state with a visible Aries constellation mark.

## Aries canon for prototype

- Lineage: Aries / Emberhorn
- Starting Gift: First Strike
- Natural runes: Predator + Survival
- Secondary affinity: Stalker
- Rare affinity: Symbiosis
- Dangerous affinity: Void
- Stage 0: Unkindled Horn
- Stage I glyph: Predator / Hunter's Pulse
- Stage II branches: Bloodfire (Predator + Survival), Ashstalker (Predator + Stalker), Packfire (Predator + Symbiosis)
- Stage III example: Apex Pursuer (Predator + Stalker + Survival)
- Full Constellation: Aries stars become biologically visible across chest, shoulder, arm, and horn structures.
- Legendary example: Apex Emberborn.

## Architecture constraints

- Simulation state is serializable and owns progression, identity, encounters, and save data.
- Three.js is a renderer adapter, not the source of truth.
- DOM owns birth-date UI, HUD, prompts, and meditation text.
- Browser runtime: TypeScript + Vite + vanilla Three.js.
- Use GLB/glTF 2.0 for future shipped 3D assets; the first prototype may use procedural Three.js geometry so gameplay architecture is proven before asset production.
- Keep the persistent HUD low-chrome and protect the center of the playfield.
- Input actions are explicit and mapped in one place.
