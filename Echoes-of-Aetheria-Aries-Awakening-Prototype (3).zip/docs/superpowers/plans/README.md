Plans for Echoes of Aetheria prototype work live here.
