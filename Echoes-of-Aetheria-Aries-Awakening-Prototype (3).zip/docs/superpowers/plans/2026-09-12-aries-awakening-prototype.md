# Aries Awakening Prototype Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the first playable Echoes of Aetheria 3D vertical slice where a player's birth month/day awakens a zodiac lineage and an Aries player survives a hunt, unlocks Hunter's Pulse, meditates, and visibly evolves.

**Architecture:** A data-driven simulation owns identity, progression, encounters, and saveable state. Vanilla Three.js renders the simulation through a thin adapter, while DOM overlays handle birth entry, HUD, prompts, and meditation. Procedural geometry stands in for final GLB assets so the prototype validates the game loop before art production.

**Tech Stack:** TypeScript, Vite, Three.js, Vitest, DOM/CSS, browser WebGL.

**Spec:** `docs/spec/aries-awakening-prototype.md`

## Global Constraints

- The player never chooses a Martian lineage from a class menu; birth month and day awaken it.
- Birth determines the ancestral template and Starting Gift; gameplay determines Adaptive Glyphs, evolution branches, Full Constellation, and Legendary Ascension.
- Simulation state is serializable and owns progression, identity, encounters, and save data.
- Three.js is a renderer adapter, not the source of truth.
- DOM owns birth-date UI, HUD, prompts, and meditation text.
- Browser runtime: TypeScript + Vite + vanilla Three.js.
- Use GLB/glTF 2.0 for future shipped 3D assets; the first prototype may use procedural Three.js geometry.
- Keep the persistent HUD low-chrome and protect the center of the playfield.
- Input actions are explicit and mapped in one place.

---

### Task 1: Project scaffold and zodiac identity resolver

**Files:**
- Create: `package.json`, `tsconfig.json`, `vite.config.ts`, `index.html`
- Create: `src/simulation/identity/zodiac.ts`
- Create: `src/simulation/identity/lineages.ts`
- Create: `src/simulation/identity/types.ts`
- Create: `tests/simulation/identity/zodiac.test.ts`

**Interfaces:**
- `resolveZodiac(month: number, day: number): ZodiacSign`
- `getLineageForZodiac(sign: ZodiacSign): CelestialLineage`
- `CelestialLineage` contains `id`, `zodiac`, `name`, `startingGift`, `naturalRunes`, `secondaryAffinity`, `rareAffinity`, and `dangerousAffinity`.

- [ ] **Step 1: Write failing tests for Aries boundaries and adjacent signs.**

```ts
expect(resolveZodiac(3, 21)).toBe('aries');
expect(resolveZodiac(4, 19)).toBe('aries');
expect(resolveZodiac(4, 20)).toBe('taurus');
expect(resolveZodiac(12, 31)).toBe('capricorn');
expect(resolveZodiac(1, 1)).toBe('capricorn');
```

- [ ] **Step 2: Run `npm test -- --run tests/simulation/identity/zodiac.test.ts` and confirm failure because the resolver is absent.**
- [ ] **Step 3: Implement the 12 standard zodiac date ranges and data-driven lineage records, with Aries fully populated from the spec and the remaining 11 represented by their established lineage names and Starting Gifts.**
- [ ] **Step 4: Run the identity tests and the full test suite; both must pass.**
- [ ] **Step 5: Commit with `git add package.json tsconfig.json vite.config.ts index.html src tests && git commit -m "feat: add zodiac lineage identity foundation"`.**

### Task 2: Adaptive Glyph progression and Aries hunt state

**Files:**
- Create: `src/simulation/progression/types.ts`
- Create: `src/simulation/progression/evolution.ts`
- Create: `src/simulation/world/hunt.ts`
- Create: `tests/simulation/progression/evolution.test.ts`
- Create: `tests/simulation/world/hunt.test.ts`

**Interfaces:**
- `createPlayerState(lineageId: string): PlayerState`
- `recordExperience(state: PlayerState, event: ExperienceEvent): PlayerState`
- `completeHunt(state: PlayerState, preyId: string): PlayerState`
- `getNextEvolution(state: PlayerState): EvolutionDefinition | null`
- `PlayerState` is JSON-serializable and includes lineage, stage, unlockedGlyphs, memory, and evolution flags.

- [ ] **Step 1: Write failing tests that a completed first hunt adds `hunter-pulse`, records the hunt in Adaptation Memory, and makes Stage I available.**
- [ ] **Step 2: Run `npm test -- --run tests/simulation/progression/evolution.test.ts tests/simulation/world/hunt.test.ts` and confirm the expected missing-module failures.**
- [ ] **Step 3: Implement the minimal serializable progression model and Aries evolution definitions for Stage 0, Hunter's Pulse, Bloodfire, Ashstalker, Packfire, Apex Pursuer, Full Constellation, and Apex Emberborn.**
- [ ] **Step 4: Run the progression and hunt tests, then the full suite.**
- [ ] **Step 5: Commit with `git add src/simulation/progression src/simulation/world tests/simulation/progression tests/simulation/world && git commit -m "feat: add adaptive glyph and hunt progression"`.**

### Task 3: 3D renderer, movement, and procedural Emberhorn

**Files:**
- Create: `src/render/app/GameRenderer.ts`
- Create: `src/render/objects/Emberhorn.ts`
- Create: `src/render/objects/World.ts`
- Create: `src/input/actions.ts`
- Create: `src/main.ts`
- Create: `tests/simulation/progression/input-contract.test.ts`

**Interfaces:**
- `GameRenderer.sync(state: PlayerState): void`
- `createInputMap(): InputMap`
- `InputMap` exposes `moveForward`, `moveBackward`, `moveLeft`, `moveRight`, `interact`, `meditate`, and `pause` action names.

- [ ] **Step 1: Write a failing test asserting the input map exposes the exact action names and no renderer-specific input state.**
- [ ] **Step 2: Run the test and confirm failure.**
- [ ] **Step 3: Implement a Three.js scene with a low-poly procedural Emberhorn, ground, lighting, simple third-person follow camera, keyboard movement, and a nearby huntable creature marker. Keep simulation state outside meshes.**
- [ ] **Step 4: Run unit tests and `npm run build`; the build must succeed without TypeScript errors.**
- [ ] **Step 5: Commit with `git add src tests/simulation/progression/input-contract.test.ts && git commit -m "feat: add playable threejs emberhorn scene"`.**

### Task 4: Birth-date onboarding, awakening, HUD, and hunt interaction

**Files:**
- Create: `src/ui/AppUI.ts`
- Create: `src/ui/styles.css`
- Modify: `src/main.ts`
- Create: `tests/ui/birth-date.test.ts`

**Interfaces:**
- `AppUI.renderBirthEntry(onSubmit: (month: number, day: number) => void): void`
- `AppUI.showAwakening(lineage: CelestialLineage): void`
- `AppUI.showHud(state: PlayerState): void`
- `AppUI.showPrompt(text: string): void`

- [ ] **Step 1: Write a failing test for valid Aries dates producing an Emberhorn awakening and invalid dates being rejected without mutating state.**
- [ ] **Step 2: Run the UI test and confirm failure.**
- [ ] **Step 3: Implement the DOM onboarding flow, Astral Awakening copy, compact survival HUD, contextual interaction prompt, and keyboard controls hint.**
- [ ] **Step 4: Wire the hunt interaction so approaching the creature and pressing `E` completes the first hunt and updates the HUD.**
- [ ] **Step 5: Run tests and `npm run build`.**
- [ ] **Step 6: Commit with `git add src/ui src/main.ts tests/ui && git commit -m "feat: add birth awakening and survival hud"`.**

### Task 5: Meditation transformation and Aries constellation state

**Files:**
- Create: `src/ui/MeditationOverlay.ts`
- Create: `src/render/objects/Constellation.ts`
- Modify: `src/render/objects/Emberhorn.ts`
- Modify: `src/main.ts`
- Create: `tests/simulation/progression/meditation.test.ts`

**Interfaces:**
- `beginMeditation(state: PlayerState): PlayerState`
- `completeMeditation(state: PlayerState): PlayerState`
- `ConstellationRenderer.show(sign: ZodiacSign): void`

- [ ] **Step 1: Write a failing test asserting meditation is only available after Hunter's Pulse and that completion advances the player to Stage I with an evolution flag consumed.**
- [ ] **Step 2: Run the test and confirm failure.**
- [ ] **Step 3: Implement the meditation state transition and a short DOM sequence: silence, memory flashes, glyph ignition, transformation, and return to play.**
- [ ] **Step 4: Add a procedural Aries constellation that becomes visible across the Emberhorn body after meditation.**
- [ ] **Step 5: Run tests and `npm run build`.**
- [ ] **Step 6: Commit with `git add src tests/simulation/progression/meditation.test.ts && git commit -m "feat: add emberhorn meditation evolution"`.**

### Task 6: Verification and browser smoke pass

**Files:**
- Create: `tests/simulation/integration/prototype-flow.test.ts`
- Create: `docs/prototype/first-playable.md`

**Interfaces:**
- Integration flow consumes the public simulation functions from Tasks 1-5 and verifies the complete birth-to-evolution state transition.

- [ ] **Step 1: Write a failing integration test for March 21 → Aries → Emberhorn → hunt → Hunter's Pulse → meditation → Stage I.**
- [ ] **Step 2: Run the integration test and confirm failure.**
- [ ] **Step 3: Implement only the wiring needed to make the complete state transition pass.**
- [ ] **Step 4: Run `npm test -- --run` and `npm run build`; both must pass.**
- [ ] **Step 5: Run the Vite app and perform a browser smoke pass covering boot, date entry, movement, hunt interaction, meditation, constellation visibility, and resize.**
- [ ] **Step 6: Record the playable controls and verified flow in `docs/prototype/first-playable.md`, then commit with `git add tests/simulation/integration docs/prototype && git commit -m "test: verify first playable aries flow"`.**
