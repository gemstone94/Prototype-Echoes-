# Prototype Environment Rulings

- Ruling: keep simulation and rendering separated even though the sandbox cannot install external packages — this preserves the approved architecture and minimizes migration cost.
- Ruling: use a dependency-free WebGL renderer for this sandbox build — npm registry DNS is unavailable here, so a Three.js install could not be completed; the cost is that the current renderer is a temporary implementation detail and should be replaced by the planned Three.js adapter when the normal dependency environment is available.
