# First Playable: Aries Awakening

## Verified state flow

- Birth date input resolves through the zodiac resolver.
- March 21 resolves to Aries and creates the Emberhorn lineage.
- Completing the first mossback hunt records Adaptation Memory and unlocks Hunter's Pulse.
- Meditation is blocked before Hunter's Pulse.
- Meditation after the first hunt advances the Emberhorn to Stage I and consumes the pending evolution.
- The renderer exposes a procedural Emberhorn, a simple survival world, movement, and an Aries constellation mark after evolution.

## Controls

- WASD: move
- E: interact / complete the first hunt when close to the mossback marker
- M: begin meditation after Hunter's Pulse unlocks

## Local commands

```text
npm test
npm run build
npm run dev
```

`npm run dev` serves the built `dist/` directory on port 4173.

## Environment note

The build environment could not resolve external package registries, so npm installation of Three.js/Vite was unavailable. To keep the first playable slice executable in this environment, the renderer is currently a small dependency-free WebGL adapter behind the same `GameRenderer` boundary. The simulation architecture remains renderer-agnostic, and the intended production renderer can be swapped to Three.js without moving progression or identity logic into the render layer.
