# Echoes of Aetheria — Elite Core

Data-driven foundation for the locked Aetheria canon: 12 zodiac lineages, seven rune families, adaptation memory, meditation evolution, full constellation, legendary ascension, and three predator scales.

Run `npm test`.
