export const RUNE = Object.freeze({ PREDATOR:'predator', STALKER:'stalker', HERBAL:'herbal', SYMBIOSIS:'symbiosis', SURVIVAL:'survival', ASTRAL:'astral', VOID:'void' });
export const STAGES = Object.freeze({ AWAKENING:0, FIRST_GLYPH:1, RESONANCE:2, CONVERGENCE:3, TRANSCENDENCE:4, CONSTELLATION:5, ASCENSION:6 });
export const LINEAGES = Object.freeze({
 Aries:{species:'Emberhorn',gift:'First Strike',natural:[RUNE.PREDATOR,RUNE.SURVIVAL],secondary:RUNE.STALKER,rare:RUNE.SYMBIOSIS,dangerous:RUNE.VOID},
 Taurus:{species:'Stonebloom',gift:'Rooted',natural:[RUNE.SURVIVAL,RUNE.HERBAL],secondary:RUNE.SYMBIOSIS,rare:RUNE.STALKER},
 Gemini:{species:'Twin-Echo',gift:'Echo Memory',natural:[RUNE.STALKER,RUNE.ASTRAL],secondary:RUNE.SYMBIOSIS,rare:RUNE.HERBAL},
 Cancer:{species:'Tideshell',gift:'Protective Instinct',natural:[RUNE.SURVIVAL,RUNE.SYMBIOSIS],secondary:RUNE.HERBAL,rare:RUNE.ASTRAL},
 Leo:{species:'Sunmane',gift:'Resonant Command',natural:[RUNE.SYMBIOSIS,RUNE.PREDATOR],secondary:RUNE.ASTRAL,rare:RUNE.SURVIVAL},
 Virgo:{species:'Spore-Sage',gift:'Botanical Analysis',natural:[RUNE.HERBAL,RUNE.ASTRAL],secondary:RUNE.SURVIVAL,rare:RUNE.SYMBIOSIS},
 Libra:{species:'Harmonic',gift:'Shared Equilibrium',natural:[RUNE.SYMBIOSIS,RUNE.ASTRAL],secondary:RUNE.HERBAL,rare:RUNE.PREDATOR},
 Scorpio:{species:'Voidstinger',gift:'Venom Sense',natural:[RUNE.PREDATOR,RUNE.STALKER],secondary:RUNE.HERBAL,rare:RUNE.VOID},
 Sagittarius:{species:'Starstrider',gift:'Far Sight',natural:[RUNE.ASTRAL,RUNE.STALKER],secondary:RUNE.SURVIVAL,rare:RUNE.SYMBIOSIS},
 Capricorn:{species:'Cragwalker',gift:'Sure Grip',natural:[RUNE.SURVIVAL,RUNE.STALKER],secondary:RUNE.HERBAL,rare:RUNE.ASTRAL},
 Aquarius:{species:'Stormmind',gift:'Current Reader',natural:[RUNE.ASTRAL,RUNE.SURVIVAL],secondary:RUNE.SYMBIOSIS,rare:RUNE.VOID},
 Pisces:{species:'Dreamswimmer',gift:'Dream Connection',natural:[RUNE.ASTRAL,RUNE.SYMBIOSIS],secondary:RUNE.HERBAL,rare:RUNE.VOID}
});
const DATES=[['Capricorn',1,19],['Aquarius',2,18],['Pisces',3,20],['Aries',4,19],['Taurus',5,20],['Gemini',6,20],['Cancer',7,22],['Leo',8,22],['Virgo',9,22],['Libra',10,22],['Scorpio',11,21],['Sagittarius',12,21]];
export function zodiac(month,day){if(!Number.isInteger(month)||!Number.isInteger(day)||month<1||month>12||day<1||day>31) throw Error('Invalid birth date');const [name,start]=DATES.find(([,m])=>m===month&&day<=([31,29,31,30,31,30,31,31,30,31,30,31][month-1]))||['Capricorn'];let sign=name;if(month===1&&day>=20)sign='Aquarius'; else if(month===2&&day>=19)sign='Pisces'; else if(month===3&&day>=21)sign='Aries'; else if(month===4&&day>=20)sign='Taurus'; else if(month===5&&day>=21)sign='Gemini'; else if(month===6&&day>=21)sign='Cancer'; else if(month===7&&day>=23)sign='Leo'; else if(month===8&&day>=23)sign='Virgo'; else if(month===9&&day>=23)sign='Libra'; else if(month===10&&day>=23)sign='Scorpio'; else if(month===11&&day>=22)sign='Sagittarius'; else if(month===12&&day>=22)sign='Capricorn';return sign}
export function createPlayer(month,day){const sign=zodiac(month,day),l=LINEAGES[sign];return {sign,species:l.species,stage:0,glyphs:[],memory:[],runes:{},constellation:[],ascension:null,stability:1}}
export function recordMemory(p,event){return {...p,memory:[...p.memory,event]}}
export function unlockGlyph(p,rune,glyph){return {...p,glyphs:[...p.glyphs,glyph],runes:{...p.runes,[rune]:(p.runes[rune]||0)+1}}}
export function canMeditate(p){return p.stage<STAGES.ASCENSION && p.glyphs.length>0}
export function meditate(p){if(!canMeditate(p))throw Error('Meditation requires an awakened glyph');return {...p,stage:Math.min(STAGES.ASCENSION,p.stage+1)}}
export function constellation(p){return p.stage>=STAGES.CONSTELLATION?{...p,constellation:p.sign==='Aries'?['Hamal','Sheratan','Mesarthim','41 Ari','Botein','35 Ari','39 Ari']:Array.from({length:5},(_,i)=>`${p.sign}-${i+1}`)}:p}
export function ascension(p){if(p.stage<STAGES.CONSTELLATION)throw Error('Full constellation required');const top=Object.entries(p.runes).sort((a,b)=>b[1]-a[1])[0]?.[0]||RUNE.ASTRAL;return {...p,stage:STAGES.ASCENSION,ascension:`${p.sign} ${top} Ascendant`}}
export const PREDATOR_TIERS=Object.freeze({STALKER:{minMass:1.2,risk:0.45,beauty:0.8},APEX_BEAST:{minMass:8,risk:0.85,beauty:0.95},ASTRAL_TITAN:{minMass:80,risk:1,beauty:1}});
export function predatorAwareness(distance, tier){const t=PREDATOR_TIERS[tier];return Math.max(0,Math.min(1,(t.minMass/(distance+1))*t.risk))}
export function predatorEvent(tier,seed=1){const t=PREDATOR_TIERS[tier];return {tier,scale:t.minMass,beauty:t.beauty,danger:t.risk,pulse:Math.abs(Math.sin(seed*12.9898))*t.risk}}
