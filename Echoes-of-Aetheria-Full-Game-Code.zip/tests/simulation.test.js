import test from 'node:test';
import assert from 'node:assert/strict';
import { zodiacFromBirth, createPlayer, recordMemory, unlockGlyph, meditate, buildConstellation, legendaryAscend, predatorProfile } from '../src/sim/core.js';

test('birth date selects the Aries Emberhorn lineage', () => {
  assert.equal(zodiacFromBirth(3, 21), 'Aries');
  assert.equal(createPlayer(3, 21).species, 'Emberhorn');
});

test('survival memories unlock glyphs and advance evolution through meditation', () => {
  let p = createPlayer(3, 21);
  p = recordMemory(p, { type: 'hunt', target: 'Mossback' });
  p = unlockGlyph(p, 'predator', 'Hunter Pulse');
  assert.equal(p.memories.length, 1);
  p = meditate(p);
  assert.equal(p.stage, 1);
});

test('full constellation precedes legendary ascension', () => {
  let p = createPlayer(3, 21);
  p = unlockGlyph(p, 'predator', 'Hunter Pulse');
  for (let i = 0; i < 5; i++) p = meditate(p);
  p = buildConstellation(p);
  assert.equal(p.stage, 5);
  p = legendaryAscend(p);
  assert.equal(p.stage, 6);
  assert.match(p.ascension, /Aries/);
});

test('astral titans are enormous, beautiful and dangerous', () => {
  const titan = predatorProfile('Astral Titan');
  assert.ok(titan.massScale >= 80);
  assert.equal(titan.beauty, 1);
  assert.equal(titan.danger, 1);
});
