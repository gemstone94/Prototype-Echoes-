# Echoes of Aetheria — Full Game Foundation

A browser-playable Three.js vertical slice implementing the locked Aetheria direction.

## Play
Serve this folder with any static server because ES modules are used. Example: `python3 -m http.server 4173` and open `http://localhost:4173`.

## Controls
WASD move · E hunt · M meditate.

## Current vertical slice
Birth date → Aries → Emberhorn → Astronomical Aetheria → Mossback hunt → Adaptation Memory → Hunter's Pulse → Evolution Meditation.

## Architecture
`src/sim` is deterministic game logic. `index.html` is the current render adapter and UI shell. Production assets should be GLB/glTF and loaded through dedicated Three.js loaders as the asset pipeline matures.
