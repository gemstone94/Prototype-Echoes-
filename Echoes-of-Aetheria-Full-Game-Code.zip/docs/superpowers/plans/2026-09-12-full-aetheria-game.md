# Echoes of Aetheria Full Game Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a browser-playable vertical slice of Echoes of Aetheria with the locked birth-date lineage system, adaptive evolution, Astronomical Aetheria rendering, and massive predator ecology.

**Architecture:** Simulation state is pure data and independent of Three.js. The renderer is an adapter over simulation state. DOM UI handles menus/HUD. The first release uses procedural geometry so the prototype runs immediately, with GLB asset loading reserved for production assets.

**Tech Stack:** TypeScript/JavaScript modules, Vite, Three.js, WebGL, DOM UI, Node test runner for pure simulation tests.

**Spec:** Existing Echoes of Aetheria concept files and locked project decisions in conversation.

## Global Constraints
- Birth month/day determines starting zodiac lineage.
- Experience, memories, glyphs and meditations drive evolution.
- Aetheria is astronomical, ethereal and bioluminescent.
- Predators are massive, beautiful and dangerous, with Stalker, Apex Beast and Astral Titan scales.
- Simulation state must not live inside render meshes.
- Evolution must visibly affect creature anatomy and celestial markings.

---

### Task 1: Simulation core
- [x] Write failing tests for lineage, memory, glyphs, evolution and predators.
- [x] Implement minimal pure simulation modules.
- [x] Verify tests.

### Task 2: Browser renderer
- [x] Build Three.js scene, astronomical sky, terrain, bioluminescent flora, Emberhorn and Mossback.
- [x] Add third-person camera and movement.
- [x] Add predator presentation hooks.

### Task 3: Game loop and UI
- [x] Add birth-date awakening screen.
- [x] Add hunt, adaptation memory and meditation flow.
- [x] Add stage/constellation HUD.

### Task 4: Packaging
- [x] Add Vite config and npm scripts.
- [x] Add README and browser instructions.
- [x] Run tests and production build.
