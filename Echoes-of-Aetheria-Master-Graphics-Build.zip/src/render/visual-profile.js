const PALETTES = Object.freeze({
  Fire: {sky:0x070b1c, nebula:0x3a123b, aura:0xff6f4e, emissive:0xffb06a},
  Earth: {sky:0x06101a, nebula:0x153d42, aura:0x8ce3a7, emissive:0x9fffc7},
  Air: {sky:0x071322, nebula:0x263f69, aura:0x8ad9ff, emissive:0xc4f1ff},
  Water: {sky:0x04101b, nebula:0x123d55, aura:0x5ed8ff, emissive:0x8df5ff}
});
export function visualProfileFromPhenotype(p={}){return{
 bodyScale:{x:.78+(p.mass??1)*.62,y:.62+(p.armor??.5)*.3,z:.95+(p.mass??1)*.82},
 glowIntensity:1.2+(p.luminescence??.5)*2.4,
 rimIntensity:.45+(p.senses??.5)*.9,
 armorDensity:.25+(p.armor??.5)*.75,
 limbCount:p.limbCount??4,
 eyeScale:.8+(p.senses??.5)*.5
};}
export function celestialPalette(c={}){return PALETTES[c.element]||PALETTES.Air;}
