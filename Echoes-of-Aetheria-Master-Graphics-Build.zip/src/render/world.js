import * as THREE from 'https://unpkg.com/three@0.180.0/build/three.module.js';
import {EffectComposer} from 'https://unpkg.com/three@0.180.0/examples/jsm/postprocessing/EffectComposer.js';
import {RenderPass} from 'https://unpkg.com/three@0.180.0/examples/jsm/postprocessing/RenderPass.js';
import {UnrealBloomPass} from 'https://unpkg.com/three@0.180.0/examples/jsm/postprocessing/UnrealBloomPass.js';
import {visualProfileFromPhenotype, celestialPalette} from './visual-profile.js';

const TAU=Math.PI*2;
const V3=THREE.Vector3;
const makeGlow=(color,intensity=1,opacity=.5)=>new THREE.MeshBasicMaterial({color,transparent:true,opacity,blending:THREE.AdditiveBlending,depthWrite:false,toneMapped:false});

function noiseGroundMaterial(){
 const uniforms={time:{value:0},lum:{value:.7}};
 return {uniforms,material:new THREE.ShaderMaterial({uniforms,transparent:false,vertexShader:`varying vec3 vPos; varying vec3 vNormal; void main(){vPos=(modelMatrix*vec4(position,1.)).xyz;vNormal=normalize(mat3(modelMatrix)*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`uniform float time;uniform float lum;varying vec3 vPos;varying vec3 vNormal;float hash(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);float a=hash(i),b=hash(i+vec2(1,0)),c=hash(i+vec2(0,1)),d=hash(i+vec2(1,1));return mix(mix(a,b,f.x),mix(c,d,f.x),f.y);}void main(){float n=noise(vPos.xz*.035)+.45*noise(vPos.xz*.12);float rings=.5+.5*sin(length(vPos.xz)*.09-n*2.);vec3 base=mix(vec3(.012,.045,.042),vec3(.025,.12,.095),n*.7);base+=vec3(.01,.13,.09)*pow(rings,7.)*lum;float edge=pow(1.-max(0.,dot(normalize(vNormal),vec3(0,1,0))),3.);base+=vec3(.08,.2,.22)*edge;gl_FragColor=vec4(base,1.);}`})};
}

function createStarfield(){
 const count=2400,pos=new Float32Array(count*3),size=new Float32Array(count),col=new Float32Array(count*3);
 for(let i=0;i<count;i++){const r=330+Math.random()*250,theta=Math.random()*TAU,phi=Math.acos(2*Math.random()-1);pos[i*3]=r*Math.sin(phi)*Math.cos(theta);pos[i*3+1]=Math.abs(r*Math.cos(phi))+18;pos[i*3+2]=r*Math.sin(phi)*Math.sin(theta);size[i]=1+Math.random()*3;const c=new THREE.Color().setHSL(.52+Math.random()*.18,.35+.35*Math.random(),.65+.3*Math.random());col.set([c.r,c.g,c.b],i*3);}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(pos,3));g.setAttribute('aSize',new THREE.BufferAttribute(size,1));g.setAttribute('color',new THREE.BufferAttribute(col,3));
 const m=new THREE.ShaderMaterial({vertexColors:true,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,uniforms:{pixelRatio:{value:Math.min(devicePixelRatio,2)}},vertexShader:`attribute float aSize;varying vec3 vColor;uniform float pixelRatio;void main(){vColor=color;vec4 mv=modelViewMatrix*vec4(position,1.);gl_PointSize=aSize*pixelRatio*(360./-mv.z);gl_Position=projectionMatrix*mv;}`,fragmentShader:`varying vec3 vColor;void main(){float d=distance(gl_PointCoord,vec2(.5));float a=smoothstep(.5,.02,d);gl_FragColor=vec4(vColor,a);}`});
 return new THREE.Points(g,m);
}

function createNebula(){
 const geo=new THREE.SphereGeometry(310,64,32);
 const mat=new THREE.ShaderMaterial({side:THREE.BackSide,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,uniforms:{time:{value:0}},vertexShader:`varying vec3 vWorld;void main(){vWorld=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`uniform float time;varying vec3 vWorld;float hash(vec3 p){return fract(sin(dot(p,vec3(12.9898,78.233,37.719)))*43758.5453);}float fbm(vec3 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*hash(floor(p));p=p*2.03+11.;a*=.5;}return v;}void main(){vec3 d=normalize(vWorld);float n=fbm(d*5.+vec3(time*.006,0.,-time*.003));float band=pow(max(0.,1.-abs(d.y+.08)*2.1),3.);vec3 c=mix(vec3(.03,.06,.16),vec3(.24,.04,.25),n)*band;float a=.08+band*n*.18;gl_FragColor=vec4(c,a);}`});
 return new THREE.Mesh(geo,mat);
}

function createAtmosphere(){
 const mat=new THREE.ShaderMaterial({side:THREE.BackSide,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,uniforms:{color:{value:new THREE.Color(0x3fd8c0)},intensity:{value:1}},vertexShader:`varying vec3 vNormal;void main(){vNormal=normalize(normalMatrix*normal);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`uniform vec3 color;uniform float intensity;varying vec3 vNormal;void main(){float fresnel=pow(1.-max(0.,dot(vNormal,vec3(0.,0.,1.))),3.);gl_FragColor=vec4(color,fresnel*.22*intensity);}`});
 return new THREE.Mesh(new THREE.SphereGeometry(205,64,32),mat);
}

function createFlora(){
 const group=new THREE.Group(),h=.9+Math.random()*5.8,petals=5+Math.floor(Math.random()*4),base=new THREE.Group();
 const stem=new THREE.Mesh(new THREE.CylinderGeometry(.035,.11,h,7),new THREE.MeshStandardMaterial({color:0x163f36,roughness:.9,metalness:.05}));stem.position.y=h/2;base.add(stem);
 for(let j=0;j<3;j++){const leaf=new THREE.Mesh(new THREE.SphereGeometry(.13+j*.025,7,5),new THREE.MeshStandardMaterial({color:0x1c6551,emissive:0x0d5b42,emissiveIntensity:1.4,roughness:.7}));leaf.scale.set(.35,1.6,.18);leaf.position.set(Math.cos(j*2.1)*.3,.35+j*h*.2,Math.sin(j*2.1)*.3);leaf.rotation.z=(j-1)*.5;base.add(leaf);}
 const bloom=new THREE.Group();for(let j=0;j<petals;j++){const p=new THREE.Mesh(new THREE.SphereGeometry(.16+Math.random()*.08,8,6),new THREE.MeshStandardMaterial({color:0x6be8c0,emissive:0x45e0b1,emissiveIntensity:4.5,roughness:.3}));const a=j*TAU/petals;p.position.set(Math.cos(a)*.28,0,Math.sin(a)*.28);p.scale.y=.42;bloom.add(p);}const core=new THREE.Mesh(new THREE.SphereGeometry(.13,10,8),makeGlow(0xcaffed,2,.9));bloom.add(core);bloom.position.y=h;base.add(bloom);group.add(base);return {group,bloom,phase:Math.random()*TAU};
}

function creatureMaterial(kind,profile){const base=kind==='predator'?0x241326:kind==='titan'?0x101526:0x214d45;const glow=kind==='predator'?0x8c315e:kind==='titan'?0x5130a0:0x197a62;return new THREE.MeshStandardMaterial({color:base,emissive:glow,emissiveIntensity:profile.glowIntensity,roughness:.5+.35*(1-profile.armorDensity),metalness:.12});}

function createProceduralCreature(kind,scale=1,entity={}){
 const p=visualProfileFromPhenotype(entity.phenotype||{}),g=new THREE.Group(),mat=creatureMaterial(kind,p),skin=new THREE.Group();
 const body=new THREE.Mesh(new THREE.IcosahedronGeometry(.72,2),mat);body.scale.set(p.bodyScale.x,p.bodyScale.y,p.bodyScale.z);skin.add(body);
 const chest=new THREE.Mesh(new THREE.SphereGeometry(.52,20,12),mat);chest.position.z=.62;chest.scale.set(.95,.8,.7);skin.add(chest);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.48,18,12),mat);head.position.set(0,.52,-.72);head.scale.set(1,.9,1.1);skin.add(head);
 const eyeMat=makeGlow(kind==='predator'?0xff9ac7:kind==='titan'?0x9ce9ff:0xc8fff0,p.rimIntensity,.95);for(const x of [-.18,.18]){const eye=new THREE.Mesh(new THREE.SphereGeometry(.075*p.eyeScale,10,8),eyeMat);eye.position.set(x,.62,-1.08);skin.add(eye);}
 const limbs=Math.max(2,Math.min(8,p.limbCount));for(let i=0;i<limbs;i++){const a=TAU*i/limbs;const l=new THREE.Mesh(new THREE.CapsuleGeometry(.055+.035*p.armorDensity,.52+.12*p.bodyScale.y,5,8),mat);l.position.set(Math.cos(a)*.48,-.42,Math.sin(a)*.58);l.rotation.z=Math.cos(a)*.55;l.rotation.x=Math.sin(a)*.35;skin.add(l);}
 const crest=new THREE.Mesh(new THREE.ConeGeometry(.14+.16*p.armorDensity,.75+.55*p.armorDensity,8),new THREE.MeshStandardMaterial({color:0x4c203f,emissive:0xc33c79,emissiveIntensity:2.4}));crest.position.set(0,1.05,.05);skin.add(crest);
 if(kind==='predator'||entity.tier==='Apex Beast'){for(const x of [-.34,.34]){const horn=new THREE.Mesh(new THREE.ConeGeometry(.1+.06*p.mass,1+.35*p.mass,8),new THREE.MeshStandardMaterial({color:0x6b3441,emissive:0xf16b46,emissiveIntensity:3}));horn.position.set(x,.88,-.45);horn.rotation.z=x>0?-.35:.35;skin.add(horn);}}
 const aura=new THREE.Mesh(new THREE.TorusGeometry(1.25+.25*p.mass,.018+.015*p.rimIntensity,8,64),makeGlow(kind==='titan'?0x74dfff:0xff6cae,.9,.45));aura.rotation.x=Math.PI/2;aura.position.y=.05;skin.add(aura);
 if(entity.tier==='Apex Beast'){for(let i=0;i<3;i++){const ring=new THREE.Mesh(new THREE.TorusGeometry(1.45+i*.3,.012,6,48),makeGlow(0xffb47a,1,.22));ring.rotation.x=Math.PI/2+i*.25;ring.rotation.z=i*.6;skin.add(ring);}}
 if(entity.tier==='Astral Titan'){skin.scale.set(5.5,2.4,7);for(let i=0;i<6;i++){const ring=new THREE.Mesh(new THREE.TorusGeometry(6.8+i*1.1,.06,8,80),makeGlow(0x7ee7ff,1.1,.18));ring.rotation.x=.5+i*.08;ring.rotation.y=i*.4;g.add(ring);}}
 g.add(skin);g.scale.setScalar(scale);g.userData.phenotype=p;return g;
}

export function createWorld(){
 const scene=new THREE.Scene();scene.background=new THREE.Color(0x02040c);scene.fog=new THREE.FogExp2(0x07111b,.0095);
 const camera=new THREE.PerspectiveCamera(60,innerWidth/innerHeight,.1,1800);camera.position.set(0,4.8,12);
 const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(innerWidth,innerHeight);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.08;
 const composer=new EffectComposer(renderer);composer.setPixelRatio(Math.min(devicePixelRatio,2));composer.setSize(innerWidth,innerHeight);const renderPass=new RenderPass(scene,camera);const bloom=new UnrealBloomPass(new THREE.Vector2(innerWidth,innerHeight),1.25,.75,.72);composer.addPass(renderPass);composer.addPass(bloom);
 const hemi=new THREE.HemisphereLight(0x8eb5d8,0x07150f,1.1);scene.add(hemi);const moon=new THREE.DirectionalLight(0xbcd7ff,2.2);moon.position.set(-45,65,20);scene.add(moon);
 const rim=new THREE.PointLight(0x4fe6ce,35,85,2);rim.position.set(0,9,-18);scene.add(rim);
 const groundInfo=noiseGroundMaterial();const ground=new THREE.Mesh(new THREE.PlaneGeometry(500,500,1,1),groundInfo.material);ground.rotation.x=-Math.PI/2;scene.add(ground);
 const stars=createStarfield();scene.add(stars);const nebula=createNebula();scene.add(nebula);const atmosphere=createAtmosphere();scene.add(atmosphere);
 const flora=[];for(let i=0;i<250;i++){const f=createFlora();f.group.position.set((Math.random()-.5)*190,0,(Math.random()-.5)*190);f.group.rotation.y=Math.random()*TAU;scene.add(f.group);flora.push(f);}
 const crystals=[];for(let i=0;i<100;i++){const h=.6+Math.random()*4.5,r=.18+Math.random()*.5;const g=new THREE.Group();const c=new THREE.Mesh(new THREE.OctahedronGeometry(r,1),new THREE.MeshStandardMaterial({color:0x21456b,emissive:0x18548a,emissiveIntensity:3.8,roughness:.22,metalness:.3,transparent:true,opacity:.92}));c.scale.y=h/r;g.add(c);const halo=new THREE.Mesh(new THREE.SphereGeometry(r*2.2,12,8),makeGlow(0x62cfff,1,.08));g.add(halo);g.position.set((Math.random()-.5)*190,h/2,(Math.random()-.5)*190);scene.add(g);crystals.push(g);}
 const ember=createProceduralCreature('prey',1.05,{phenotype:{mass:1.1,armor:.65,senses:.9,luminescence:1,limbCount:4}});scene.add(ember);
 const moss=createProceduralCreature('prey',.9,{phenotype:{mass:1,armor:.7,senses:.55,luminescence:.8,limbCount:4}});scene.add(moss);
 const titan=createProceduralCreature('titan',1,{tier:'Astral Titan',phenotype:{mass:8,armor:1,senses:1,luminescence:1,limbCount:6}});titan.position.set(70,11,-150);scene.add(titan);
 const constellation=new THREE.Group(),constellationLines=new THREE.Group(),constellationStars=new THREE.Group();constellation.add(constellationLines,constellationStars);scene.add(constellation);
 const ecologyVisuals=new Map();
 const makeCreature=(kind,scale=1,entity={})=>createProceduralCreature(kind,scale,entity);
 return {scene,camera,renderer,composer,bloom,ground,groundUniforms:groundInfo.uniforms,stars,nebula,atmosphere,flora,crystals,ember,moss,titan,constellation,constellationStars,constellationLines,ecologyVisuals,makeCreature};
}

export function setCelestialVisual(world,celestial,stage=0){
 world.constellationStars.clear();world.constellationLines.clear();const points=celestial.sign==='Aries'?[[0,1.9],[.65,1.45],[1.1,.9],[.55,.2],[-.15,-.2],[-.7,-.55],[-1.1,-.9]]:Array.from({length:7},(_,i)=>[Math.cos(i*.9)*1.05,Math.sin(i*.9)*1.05]);const palette=celestialPalette(celestial);world.atmosphere.material.uniforms.color.value.setHex(palette.aura);world.bloom.strength=1.12+stage*.12;
 points.forEach(([x,y],i)=>{const star=new THREE.Mesh(new THREE.SphereGeometry(.055+stage*.016,10,8),makeGlow(palette.emissive,2,.95));star.position.set(x,y,0);world.constellationStars.add(star);if(i){const a=points[i-1],b=points[i],dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy);const line=new THREE.Mesh(new THREE.CylinderGeometry(.012+stage*.002,.012+stage*.002,len,6),makeGlow(palette.aura,1,.55));line.position.set((a[0]+b[0])/2,(a[1]+b[1])/2,0);line.rotation.z=Math.atan2(dy,dx)-Math.PI/2;world.constellationLines.add(line);}});world.constellation.userData.sign=celestial.sign;world.constellation.userData.birthStar=celestial.birthStar;
}

export function updateEvolutionVisual(world,player,time){
 const stage=player.stage;world.ember.scale.setScalar(1+stage*.055);world.ember.position.y=1.15+Math.sin(time*.0018)*.08;world.ember.userData.stage=stage;world.ember.userData.runes={...player.runes};world.constellation.visible=stage>=5;world.constellation.position.copy(player.position||world.ember.position);world.constellation.position.y+=3.35;world.constellation.rotation.z=Math.sin(time*.00015)*.04;world.constellation.scale.setScalar(1+stage*.07);
 if(stage>=4){world.bloom.strength=1.45+stage*.1;}else world.bloom.strength=1.12;
}

export function updateWorld(world,time,playerPos,player=null,ecosystem=null){
 world.groundUniforms.time.value=time*.001;world.groundUniforms.lum.value=.65+.18*Math.sin(time*.0004);world.nebula.material.uniforms.time.value=time*.001;world.stars.rotation.y=time*.000006;world.atmosphere.rotation.y=time*.00002;
 for(const f of world.flora){f.bloom.scale.setScalar(1+.13*Math.sin(time*.0014+f.phase));f.group.rotation.y+=Math.sin(time*.0003+f.phase)*.0003;}
 world.ember.rotation.y=.05*Math.sin(time*.0008);world.ember.position.lerp(playerPos,.24);world.camera.position.lerp(new V3(playerPos.x,playerPos.y+4.55,playerPos.z+11.5),.075);world.camera.lookAt(playerPos.x,playerPos.y+1.05,playerPos.z-2.2);world.titan.rotation.y=time*.00004;
 if(ecosystem){const live=new Set();for(const e of ecosystem.entities){if(e.kind==='flora')continue;live.add(e.id);let mesh=e.id==='mossback-0'?world.moss:world.ecologyVisuals.get(e.id);if(!mesh){mesh=world.makeCreature(e.kind,e.kind==='titan'?1:1,e);world.scene.add(mesh);world.ecologyVisuals.set(e.id,mesh);}const scale=e.kind==='titan'?1:e.tier==='Apex Beast'?1.8:e.kind==='predator'?1.1:.72;mesh.scale.setScalar(scale);mesh.position.set(e.position.x,e.kind==='titan'?11:.8,e.position.z);mesh.visible=e.population>.08;mesh.rotation.y=Math.atan2(e.position.x-e.home.x,e.position.z-e.home.z);mesh.userData.state=e.state;mesh.userData.species=e.species;mesh.userData.tier=e.tier;const targetY=e.state==='fleeing'?.96:.8;mesh.position.y+=Math.sin(time*.006+e.phase)*.025;if(e.tier==='Astral Titan'){mesh.position.y=11;mesh.scale.setScalar(1);}}
 for(const [id,mesh] of world.ecologyVisuals)if(!live.has(id)){world.scene.remove(mesh);world.ecologyVisuals.delete(id);}}
 if(player)updateEvolutionVisual(world,player,time);
}
