export const STAGE=Object.freeze({AWAKENING:0,FIRST_GLYPH:1,RESONANCE:2,CONVERGENCE:3,TRANSCENDENCE:4,CONSTELLATION:5,ASCENSION:6});
export const RUNE=Object.freeze({PREDATOR:'predator',STALKER:'stalker',HERBAL:'herbal',SYMBIOSIS:'symbiosis',SURVIVAL:'survival',ASTRAL:'astral',VOID:'void'});
export const LINEAGES=Object.freeze({
 Aries:{species:'Emberhorn',gift:'First Strike',natural:[RUNE.PREDATOR,RUNE.SURVIVAL]},Taurus:{species:'Stonebloom',gift:'Rooted',natural:[RUNE.SURVIVAL,RUNE.HERBAL]},Gemini:{species:'Twin-Echo',gift:'Echo Memory',natural:[RUNE.STALKER,RUNE.ASTRAL]},Cancer:{species:'Tideshell',gift:'Protective Instinct',natural:[RUNE.SURVIVAL,RUNE.SYMBIOSIS]},Leo:{species:'Sunmane',gift:'Resonant Command',natural:[RUNE.SYMBIOSIS,RUNE.PREDATOR]},Virgo:{species:'Spore-Sage',gift:'Botanical Analysis',natural:[RUNE.HERBAL,RUNE.ASTRAL]},Libra:{species:'Harmonic',gift:'Shared Equilibrium',natural:[RUNE.SYMBIOSIS,RUNE.ASTRAL]},Scorpio:{species:'Voidstinger',gift:'Venom Sense',natural:[RUNE.PREDATOR,RUNE.STALKER]},Sagittarius:{species:'Starstrider',gift:'Far Sight',natural:[RUNE.ASTRAL,RUNE.STALKER]},Capricorn:{species:'Cragwalker',gift:'Sure Grip',natural:[RUNE.SURVIVAL,RUNE.STALKER]},Aquarius:{species:'Stormmind',gift:'Current Reader',natural:[RUNE.ASTRAL,RUNE.SURVIVAL]},Pisces:{species:'Dreamswimmer',gift:'Dream Connection',natural:[RUNE.ASTRAL,RUNE.SYMBIOSIS]}
});
const START=[0,20,19,21,20,21,21,23,23,23,23,22,22];
export function zodiacFromBirth(month,day){const max=[0,31,29,31,30,31,30,31,31,30,31,30,31][month];if(!Number.isInteger(month)||!Number.isInteger(day)||month<1||month>12||day<1||day>max)throw Error('Invalid birth date');return day>=START[month] ? ['Capricorn','Aquarius','Pisces','Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn'][month] : ['Capricorn','Aquarius','Pisces','Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn'][month-1]}
export function createPlayer(month,day){const sign=zodiacFromBirth(month,day),l=LINEAGES[sign];return {sign,species:l.species,gift:l.gift,month,day,stage:0,memories:[],glyphs:[],runes:{},constellation:[],ascension:null,ascensionPathway:null,adaptation:0,celestial:celestialSignature(sign,month,day)}}
export function recordMemory(p,m){return {...p,memories:[...p.memories,m],adaptation:p.adaptation+1}}
export function unlockGlyph(p,rune,name){return {...p,glyphs:[...p.glyphs,{rune,name}],runes:{...p.runes,[rune]:(p.runes[rune]||0)+1},adaptation:p.adaptation+2}}
export function meditate(p){if(!p.glyphs.length)throw Error('A glyph is required');return {...p,stage:Math.min(5,p.stage+1)}}
export function buildConstellation(p){if(p.stage<5)throw Error('Full constellation required');return {...p,constellation:p.sign==='Aries'?['Hamal','Sheratan','Mesarthim','41 Ari','Botein','35 Ari','39 Ari']:Array.from({length:7},(_,i)=>`${p.sign}-${i+1}`)}}
export function legendaryAscend(p){if(p.stage<5||!p.constellation.length)throw Error('Constellation required');return {...p,stage:6,ascension:`${p.sign} ${p.species} Legendary Ascension`,ascensionPathway:ascensionPath(p)}}
export function combineRunes(runes){const key=[...new Set(runes)].sort().join('+');const combos={'astral+predator':{name:'Astral Hunt',runes:['predator','astral'],rarity:'rare'},'herbal+symbiosis':{name:'Verdant Communion',runes:['herbal','symbiosis'],rarity:'rare'},'astral+survival':{name:'Starward Shell',runes:['astral','survival'],rarity:'rare'}};return combos[key]||null}
export const PREDATORS=Object.freeze({'Stalker':{massScale:1.5,beauty:.8,danger:.5},'Apex Beast':{massScale:10,beauty:.96,danger:.85},'Astral Titan':{massScale:100,beauty:1,danger:1}});
export function predatorProfile(tier){if(!PREDATORS[tier])throw Error('Unknown predator tier');return {tier,...PREDATORS[tier]}}

const CELESTIAL = Object.freeze({
  Aries:{element:'fire',modality:'cardinal',birthStar:'Hamal',lunarAffinity:'waxing'},
  Taurus:{element:'earth',modality:'fixed',birthStar:'Aldebaran',lunarAffinity:'full'},
  Gemini:{element:'air',modality:'mutable',birthStar:'Pollux',lunarAffinity:'waxing'},
  Cancer:{element:'water',modality:'cardinal',birthStar:'Acubens',lunarAffinity:'waning'},
  Leo:{element:'fire',modality:'fixed',birthStar:'Regulus',lunarAffinity:'full'},
  Virgo:{element:'earth',modality:'mutable',birthStar:'Spica',lunarAffinity:'waning'},
  Libra:{element:'air',modality:'cardinal',birthStar:'Zubeneschamali',lunarAffinity:'waxing'},
  Scorpio:{element:'water',modality:'fixed',birthStar:'Antares',lunarAffinity:'new'},
  Sagittarius:{element:'fire',modality:'mutable',birthStar:'Kaus Australis',lunarAffinity:'waxing'},
  Capricorn:{element:'earth',modality:'cardinal',birthStar:'Deneb Algedi',lunarAffinity:'waning'},
  Aquarius:{element:'air',modality:'fixed',birthStar:'Sadalsuud',lunarAffinity:'new'},
  Pisces:{element:'water',modality:'mutable',birthStar:'Alrescha',lunarAffinity:'full'}
});

const MUTATIONS = Object.freeze({
  'predator+stalker': {name:'Apex Pursuer',physical:['crystalline shoulder plates','multi-layer light-sensitive eyes','backward-swept horn growth'],ability:'predict escape routes',biomeAffinity:'adaptive'},
  'astral+symbiosis': {name:'Resonance Weaver',physical:['floating resonance nodes','luminous connective filaments'],ability:'translate biological resonance',biomeAffinity:'living networks'},
  'herbal+survival': {name:'Verdant Bastion',physical:['rootlike mineral ribs','protective botanical plating'],ability:'cultivate restorative growth',biomeAffinity:'fertile biomes'},
  'astral+void': {name:'Null Seer',physical:['dark star-like ocular flecks','broken halo structures'],ability:'sense anomalies through absence',biomeAffinity:'anomalous zones'},
  'predator+void': {name:'Blackfire',physical:['light-absorbing crystalline veins','silent horn fissures'],ability:'suppress biological detection',biomeAffinity:'shadow biomes'}
});

function runeKey(runes){return [...new Set(runes)].sort().join('+')}
export function celestialSignature(sign,month,day){
  const base=CELESTIAL[sign];
  const phaseIndex=(month*31+day)%4;
  const phase=['new','waxing','full','waning'][phaseIndex];
  return Object.freeze({...base,lunarAffinity:phase,month,day});
}

export function deriveMutation(p){
  const runes=Object.keys(p.runes||{}).filter(k=>(p.runes[k]||0)>0);
  const pair=MUTATIONS[runeKey(runes.slice(0,2))] || MUTATIONS[runeKey(runes)];
  if(pair)return {...pair,biomeAffinity:p.memories.at(-1)?.biome || pair.biomeAffinity};
  return {name:'Ancestral Resonance',physical:['subdermal constellation glow'],ability:p.gift,biomeAffinity:p.memories.at(-1)?.biome || 'unknown'};
}

export function ecologicalResonance(p){
  const voidCount=p.runes?.[RUNE.VOID]||0;
  const symbiosisCount=p.runes?.[RUNE.SYMBIOSIS]||0;
  return {voidInstability:Math.min(1,voidCount*.22),symbiosisPenalty:Math.min(1,voidCount*symbiosisCount*.08),symbiosisStrength:Math.min(1,symbiosisCount*.15)};
}

const ASCENSION_BY_LINEAGE=Object.freeze({Aries:'Apex Emberborn',Taurus:'Worldroot Stonebloom',Gemini:'Infinite Echo',Cancer:'Tide Guardian',Leo:'Sun Sovereign',Virgo:'Spore Oracle',Libra:'Harmonic Ascendant',Scorpio:'Voidstinger',Sagittarius:'Starstrider Eternal',Capricorn:'Worldcrag',Aquarius:'Stormmind Ascendant',Pisces:'Dreamwalker'});
export function ascensionPath(p){
  const runes=Object.keys(p.runes||{}).filter(k=>(p.runes[k]||0)>0);
  if(p.sign==='Aries'&&runes.includes(RUNE.PREDATOR)&&runes.includes(RUNE.STALKER))return 'Apex Emberborn';
  if(p.sign==='Scorpio'&&runes.includes(RUNE.PREDATOR)&&runes.includes(RUNE.VOID))return 'Voidstinger';
  return ASCENSION_BY_LINEAGE[p.sign] || `${p.sign} Ascendant`;
}
