# Living Biosphere Leap Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Evolve Aetheria's ecosystem from local creature reactions into a deterministic biosphere simulation with intelligence, social behavior, genetics, trophic balance, reproduction, migration, territorial conflict, symbiosis, environmental events, Apex Beasts, and Astral Titans.

**Architecture:** Keep all world rules in `src/simulation/ecology.js`, with pure helpers for perception, decisions, genetics, population flow, territory, and events. Rendering consumes compact snapshots and creates visual bodies from genome data; it never owns AI or progression state.

**Tech Stack:** JavaScript ES modules, Node's built-in `node:test`, Three.js renderer, Vite/static browser runtime.

**Spec:** Approved in-chat Biosphere architecture: Predator Intelligence; Pack/Herd Intelligence; Procedural Creature Bodies; Food Web; Reproduction; Migration; Territorial Conflict; Symbiosis; Environmental Events; Apex Beasts; Astral Titans.

## Global Constraints
- Simulation state remains independent of Three.js scene objects.
- The ecosystem must change because of modeled causes, not player-facing cheats.
- Existing 14 tests must remain green.
- New behavior must have failing tests before implementation.
- Browser runtime remains low-chrome and DOM HUD driven.

### Task 1: Biosphere data model and genetics
**Files:** Modify `src/simulation/ecology.js`; modify `tests/core.test.js`.
- [ ] Add failing tests for genome inheritance, phenotype determinism, and generational offspring.
- [ ] Run `node --test tests/core.test.js` and observe the new tests fail.
- [ ] Implement `GENOME_TRAITS`, deterministic `createGenome(seed, species)`, `inheritGenome(parentA,parentB,mutationSeed)`, and `phenotypeFromGenome(genome)`.
- [ ] Run the focused tests and then the full suite.
- [ ] Commit `feat: add biosphere genetics`.

### Task 2: Predator intelligence and social behavior
**Files:** Modify `src/simulation/ecology.js`; modify `tests/core.test.js`.
- [ ] Add failing tests for sensory scoring, stalking, pack signaling, coordinated pursuit, retreat, and memory-driven avoidance.
- [ ] Implement `SENSE`, `BEHAVIOR`, `scoreThreat`, `chooseBehavior`, `updatePack`, and `updateCreatureMind` using hunger, fear, territory, prey value, pack strength, and memories.
- [ ] Verify focused tests and full suite.
- [ ] Commit `feat: add intelligent predator packs`.

### Task 3: Food chains, reproduction, and population pressure
**Files:** Modify `src/simulation/ecology.js`; modify `tests/core.test.js`.
- [ ] Add failing tests showing flora feeds herbivores, herbivore pressure feeds predators, scarcity reduces reproduction, and healthy populations recover.
- [ ] Implement trophic transfer, energy accounting, mating readiness, gestation/cooldown, offspring creation, mortality, and bounded population recovery.
- [ ] Verify focused tests and full suite.
- [ ] Commit `feat: simulate trophic population cycles`.

### Task 4: Migration and territorial conflict
**Files:** Modify `src/simulation/ecology.js`; modify `tests/core.test.js`.
- [ ] Add failing tests for resource-driven migration, seasonal migration, territory claims, boundary warnings, and dominance conflicts.
- [ ] Implement `calculateMigrationPressure`, `updateMigration`, `claimTerritory`, and `resolveTerritorialConflict` with deterministic outcomes.
- [ ] Verify focused tests and full suite.
- [ ] Commit `feat: add migration and territorial ecology`.

### Task 5: Symbiosis and environmental events
**Files:** Modify `src/simulation/ecology.js`; modify `tests/core.test.js`.
- [ ] Add failing tests for mutualism, parasitism, host health, astral storms, blooms, void disturbances, and event modifiers.
- [ ] Implement relationship records plus an event scheduler with deterministic seeded events and reversible ecological modifiers.
- [ ] Verify focused tests and full suite.
- [ ] Commit `feat: add symbiosis and astral events`.

### Task 6: Apex Beasts and Astral Titans
**Files:** Modify `src/simulation/ecology.js`; modify `src/render/world.js`; modify `src/ui/app.js`; modify `tests/core.test.js`.
- [ ] Add failing tests for tier escalation, unique territory impact, Titan-scale environmental influence, and celestial recognition of the player.
- [ ] Implement `createApexBeast`, `createAstralTitan`, tier-specific decision rules, ecological influence fields, and player-recognition rules.
- [ ] Render genome-driven creature silhouettes, Apex bodies, and Titan rings/auras from simulation snapshots.
- [ ] Verify focused tests, full suite, module syntax, and browser HTTP smoke test.
- [ ] Commit `feat: bring apex beasts and astral titans to life`.

### Task 7: Browser integration and observability
**Files:** Modify `src/ui/app.js`; modify `src/render/world.js`; modify `README.md`.
- [ ] Add a failing integration assertion for ecosystem tick output and visible population/event telemetry.
- [ ] Connect a fixed-timestep ecosystem tick to the game loop and render only nearby/important entities.
- [ ] Add a compact ecological status readout: biome state, active event, nearby species, predator pressure, and Titan warning.
- [ ] Verify full suite, syntax, static browser response, and a short runtime smoke test.
- [ ] Commit `feat: connect biosphere to playable world`.
